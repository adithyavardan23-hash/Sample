package com.cts.energygrid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnergyGridMonolithicApplicationTests {

	@Test
	void contextLoads() {
	}

}
