package com.cts.energygrid.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cts.energygrid.dto.response.EnergyReportResponse;
import com.cts.energygrid.entity.EnergyReport;
import com.cts.energygrid.enums.ReportScope;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.EnergyReportRepository;
import com.cts.energygrid.service.impl.EnergyReportServiceImpl;

@ExtendWith(MockitoExtension.class)
class EnergyReportServiceTest {

    @Mock
    private EnergyReportRepository energyReportRepository;

    // The impl records audit entries through AuditLogService (not the repository).
    @Mock
    private AuditLogService auditLogService;

    @InjectMocks
    private EnergyReportServiceImpl energyReportService;

    @Test
    void generateReport_validScope_hasMetrics() {
        when(energyReportRepository.save(any(EnergyReport.class)))
                .thenAnswer(invocation -> {
                    EnergyReport saved = invocation.getArgument(0);
                    saved.setReportId(1L);
                    return saved;
                });

        EnergyReportResponse response = energyReportService.generateReport(ReportScope.GRID);

        assertNotNull(response.getMetrics());
        assertTrue(response.getMetrics().contains("GRID"));
        assertNotNull(response.getGeneratedDate());
    }

    @Test
    void getReportById_invalidId_throwsException() {
        when(energyReportRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> energyReportService.getReportById(99L));
    }
}
