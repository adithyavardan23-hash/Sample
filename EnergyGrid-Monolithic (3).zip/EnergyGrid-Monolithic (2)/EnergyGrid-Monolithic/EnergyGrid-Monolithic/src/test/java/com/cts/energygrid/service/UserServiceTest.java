package com.cts.energygrid.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.cts.energygrid.dto.request.UserRequest;
import com.cts.energygrid.dto.response.UserResponse;
import com.cts.energygrid.entity.User;
import com.cts.energygrid.enums.Role;
import com.cts.energygrid.enums.UserStatus;
import com.cts.energygrid.exception.BadRequestException;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.UserRepository;
import com.cts.energygrid.service.impl.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private BCryptPasswordEncoder passwordEncoder;

    @Mock
    private AuditLogService auditLogService;

    @InjectMocks
    private UserServiceImpl userService;

    private UserRequest sampleRequest() {
        UserRequest req = new UserRequest();
        req.setName("Alice Consumer");
        req.setRole(Role.CONSUMER);
        req.setEmail("alice@energygrid.com");
        req.setPassword("password123");
        req.setPhone("9876543210");
        req.setZoneId("ZONE-1");
        req.setStatus(UserStatus.ACTIVE);
        return req;
    }

    private User sampleEntity(Long id, UserStatus status) {
        User user = new User();
        user.setUserId(id);
        user.setName("Alice Consumer");
        user.setRole(Role.CONSUMER);
        user.setEmail("alice@energygrid.com");
        user.setPassword("hashed-pw");
        user.setPhone("9876543210");
        user.setZoneId("ZONE-1");
        user.setStatus(status);
        return user;
    }

    @Test
    void register_validInput_returnsSavedUser() {
        UserRequest req = sampleRequest();
        when(userRepository.existsByEmail(req.getEmail())).thenReturn(false);
        when(passwordEncoder.encode("password123")).thenReturn("hashed-pw");
        when(userRepository.save(any(User.class))).thenReturn(sampleEntity(1L, UserStatus.ACTIVE));

        UserResponse response = userService.register(req);

        assertEquals(1L, response.getUserId());
        assertEquals("alice@energygrid.com", response.getEmail());
        assertEquals(UserStatus.ACTIVE, response.getStatus());
    }

    @Test
    void register_duplicateEmail_throwsBadRequestException() {
        UserRequest req = sampleRequest();
        when(userRepository.existsByEmail(req.getEmail())).thenReturn(true);

        assertThrows(BadRequestException.class, () -> userService.register(req));
    }

    @Test
    void getUserById_validId_returnsUser() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(sampleEntity(1L, UserStatus.ACTIVE)));

        UserResponse response = userService.getUserById(1L);

        assertEquals(1L, response.getUserId());
        assertEquals("alice@energygrid.com", response.getEmail());
    }

    @Test
    void getUserById_invalidId_throwsResourceNotFoundException() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> userService.getUserById(99L));
    }

    @Test
    void updateUser_validId_changesStatus() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(sampleEntity(1L, UserStatus.ACTIVE)));
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        UserRequest req = sampleRequest();
        req.setPassword(null); // no password change on update
        req.setStatus(UserStatus.INACTIVE);

        UserResponse response = userService.updateUser(1L, req);

        assertEquals(UserStatus.INACTIVE, response.getStatus());
    }
}
