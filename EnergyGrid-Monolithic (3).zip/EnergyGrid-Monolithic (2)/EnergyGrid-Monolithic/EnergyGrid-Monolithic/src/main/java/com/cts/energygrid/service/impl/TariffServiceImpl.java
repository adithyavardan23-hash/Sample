package com.cts.energygrid.service.impl;

import com.cts.energygrid.dto.request.TariffRequest;
import com.cts.energygrid.dto.response.TariffResponse;
import com.cts.energygrid.entity.Tariff;
import com.cts.energygrid.enums.ConsumerCategory;
import com.cts.energygrid.enums.TariffStatus;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.TariffRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.TariffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TariffServiceImpl implements TariffService {

    @Autowired
    private TariffRepository tariffRepository;

    @Autowired
    private AuditLogService auditLogService;

    @Override
    public TariffResponse createTariff(TariffRequest req) {
        Tariff tariff = new Tariff();
        tariff.setName(req.getName());
        tariff.setConsumerCategory(req.getConsumerCategory());
        tariff.setSlabRates(req.getSlabRates());
        tariff.setFixedCharges(req.getFixedCharges());
        tariff.setTaxRates(req.getTaxRates());
        tariff.setEffectiveDate(req.getEffectiveDate());
        tariff.setStatus(req.getStatus());

        Tariff saved = tariffRepository.save(tariff);
        auditLogService.log("CREATE", "Tariff", String.valueOf(saved.getTariffId()), saved.getTariffId());
        return mapToResponse(saved);
    }

    @Override
    public TariffResponse getTariffById(Long id) {
        Tariff tariff = tariffRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Tariff not found with id: " + id));
        return mapToResponse(tariff);
    }

    @Override
    public List<TariffResponse> getAllTariffs() {
        return tariffRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public TariffResponse updateStatus(Long id, TariffStatus status) {
        Tariff tariff = tariffRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Tariff not found with id: " + id));
        tariff.setStatus(status);
        Tariff saved = tariffRepository.save(tariff);
        auditLogService.log("UPDATE", "Tariff", String.valueOf(saved.getTariffId()), saved.getTariffId());
        return mapToResponse(saved);
    }

    @Override
    public TariffResponse getActiveTariffByCategory(ConsumerCategory category) {
        Tariff tariff = tariffRepository.findByConsumerCategoryAndStatus(category, TariffStatus.ACTIVE)
                .orElseThrow(() -> new ResourceNotFoundException("No active tariff for category: " + category));
        return mapToResponse(tariff);
    }

    @Override
    public TariffResponse updateTariff(Long id, TariffRequest req) {
        Tariff tariff = tariffRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Tariff not found with id: " + id));
        if (req.getName() != null) {
            tariff.setName(req.getName());
        }
        if (req.getConsumerCategory() != null) {
            tariff.setConsumerCategory(req.getConsumerCategory());
        }
        if (req.getSlabRates() != null) {
            tariff.setSlabRates(req.getSlabRates());
        }
        if (req.getFixedCharges() != null) {
            tariff.setFixedCharges(req.getFixedCharges());
        }
        if (req.getTaxRates() != null) {
            tariff.setTaxRates(req.getTaxRates());
        }
        if (req.getEffectiveDate() != null) {
            tariff.setEffectiveDate(req.getEffectiveDate());
        }
        if (req.getStatus() != null) {
            tariff.setStatus(req.getStatus());
        }
        Tariff saved = tariffRepository.save(tariff);
        auditLogService.log("UPDATE", "Tariff", String.valueOf(saved.getTariffId()), saved.getTariffId());
        return mapToResponse(saved);
    }

    @Override
    public TariffResponse expireTariff(Long id) {
        Tariff tariff = tariffRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Tariff not found with id: " + id));
        tariff.setStatus(TariffStatus.EXPIRED);
        Tariff saved = tariffRepository.save(tariff);
        auditLogService.log("UPDATE", "Tariff", String.valueOf(saved.getTariffId()), saved.getTariffId());
        return mapToResponse(saved);
    }

    private TariffResponse mapToResponse(Tariff tariff) {
        return new TariffResponse(
                tariff.getTariffId(),
                tariff.getName(),
                tariff.getConsumerCategory(),
                tariff.getSlabRates(),
                tariff.getFixedCharges(),
                tariff.getTaxRates(),
                tariff.getEffectiveDate(),
                tariff.getStatus()
        );
    }
}
