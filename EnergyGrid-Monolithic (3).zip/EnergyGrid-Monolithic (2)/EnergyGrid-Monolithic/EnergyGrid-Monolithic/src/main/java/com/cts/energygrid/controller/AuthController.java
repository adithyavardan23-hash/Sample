package com.cts.energygrid.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.energygrid.dto.request.AuthRequest;
import com.cts.energygrid.dto.request.UserRequest;
import com.cts.energygrid.dto.response.AuthResponse;
import com.cts.energygrid.dto.response.UserResponse;
import com.cts.energygrid.enums.Role;
import com.cts.energygrid.enums.UserStatus;
import com.cts.energygrid.service.AuthService;
import com.cts.energygrid.service.UserService;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(
            @RequestBody AuthRequest req) {
        return ResponseEntity.ok(
            authService.login(
                req.getEmail(),
                req.getPassword()
            )
        );
    }

    @PostMapping("/register")
    public ResponseEntity<UserResponse> register(
            @RequestBody UserRequest req) {
        req.setRole(Role.CONSUMER);
        req.setStatus(UserStatus.ACTIVE);
        return ResponseEntity.ok(
            userService.register(req)
        );
    }
}