package com.cts.energygrid.service;

import java.util.List;

import com.cts.energygrid.dto.request.ConnectionRequestRequest;
import com.cts.energygrid.dto.response.ConnectionRequestResponse;
import com.cts.energygrid.enums.RequestStatus;

public interface ConnectionRequestService {

    ConnectionRequestResponse submitRequest(ConnectionRequestRequest req);

    List<ConnectionRequestResponse> getAllRequests();

    ConnectionRequestResponse assignTechnician(Long requestId, Long techId);

    ConnectionRequestResponse updateStatus(Long id, RequestStatus status);

    ConnectionRequestResponse getRequestById(Long id);

    List<ConnectionRequestResponse> getRequestsByConsumer(Long consumerId);

    List<ConnectionRequestResponse> getPendingRequests();
}
