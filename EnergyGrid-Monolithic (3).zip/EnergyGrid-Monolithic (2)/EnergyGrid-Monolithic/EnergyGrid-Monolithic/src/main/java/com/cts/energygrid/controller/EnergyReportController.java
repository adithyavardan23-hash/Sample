package com.cts.energygrid.controller;

import com.cts.energygrid.dto.response.EnergyReportResponse;
import com.cts.energygrid.enums.ReportScope;
import com.cts.energygrid.service.EnergyReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
public class EnergyReportController {

    @Autowired
    private EnergyReportService energyReportService;

    @PostMapping("/generate")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS')")
    public ResponseEntity<EnergyReportResponse> generateReport(@RequestParam ReportScope scope) {
        return ResponseEntity.ok(energyReportService.generateReport(scope));
    }

    // GET /api/reports/summary -> aggregated dashboard figures.
    @GetMapping("/summary")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS','COMPLIANCE')")
    public ResponseEntity<Map<String, Object>> getSummary() {
        return ResponseEntity.ok(energyReportService.getSummary());
    }

    @GetMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS','COMPLIANCE')")
    public ResponseEntity<List<EnergyReportResponse>> getAllReports() {
        return ResponseEntity.ok(energyReportService.getAllReports());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS','COMPLIANCE')")
    public ResponseEntity<EnergyReportResponse> getReportById(@PathVariable Long id) {
        return ResponseEntity.ok(energyReportService.getReportById(id));
    }

    @GetMapping("/scope/{scope}")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS','COMPLIANCE')")
    public ResponseEntity<List<EnergyReportResponse>> getReportsByScope(@PathVariable ReportScope scope) {
        return ResponseEntity.ok(energyReportService.getReportsByScope(scope));
    }

    @GetMapping("/period")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS','COMPLIANCE')")
    public ResponseEntity<List<EnergyReportResponse>> getReportsForPeriod(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {
        return ResponseEntity.ok(energyReportService.getReportsForPeriod(from, to));
    }
}
