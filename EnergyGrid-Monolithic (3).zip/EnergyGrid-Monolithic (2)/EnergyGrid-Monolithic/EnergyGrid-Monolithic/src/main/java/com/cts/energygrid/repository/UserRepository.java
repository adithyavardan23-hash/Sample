package com.cts.energygrid.repository;

import com.cts.energygrid.entity.User;
import com.cts.energygrid.enums.Role;
import com.cts.energygrid.enums.UserStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    List<User> findByRole(Role role);

    List<User> findByStatus(UserStatus status);

    boolean existsByEmail(String email);
}
