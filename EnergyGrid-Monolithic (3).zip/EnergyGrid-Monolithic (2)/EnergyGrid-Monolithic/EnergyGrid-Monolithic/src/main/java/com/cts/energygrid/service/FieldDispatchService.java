package com.cts.energygrid.service;

import com.cts.energygrid.dto.request.FieldDispatchRequest;
import com.cts.energygrid.dto.response.FieldDispatchResponse;
import com.cts.energygrid.enums.DispatchStatus;

import java.util.List;

public interface FieldDispatchService {

    FieldDispatchResponse dispatchTechnician(FieldDispatchRequest req);

    List<FieldDispatchResponse> getDispatchesByOutage(Long outageId);

    FieldDispatchResponse updateStatus(Long id, DispatchStatus status);

    FieldDispatchResponse getDispatchById(Long id);

    List<FieldDispatchResponse> getDispatchesByTechnician(Long techId);

    FieldDispatchResponse markOnSite(Long id);

    FieldDispatchResponse markResolved(Long id);
}
