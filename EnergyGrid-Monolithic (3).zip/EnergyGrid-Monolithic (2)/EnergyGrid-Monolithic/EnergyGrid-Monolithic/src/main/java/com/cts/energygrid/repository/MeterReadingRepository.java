package com.cts.energygrid.repository;

import com.cts.energygrid.entity.MeterReading;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface MeterReadingRepository extends JpaRepository<MeterReading, Long> {

    List<MeterReading> findByMeter_MeterId(Long meterId);

    List<MeterReading> findByMeter_MeterIdOrderByReadingDateDesc(Long meterId);

    List<MeterReading> findByMeter_MeterIdAndReadingDateBetween(Long meterId, LocalDate start, LocalDate end);
}
