package com.cts.energygrid.repository;

import com.cts.energygrid.entity.BillingDispute;
import com.cts.energygrid.enums.DisputeStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BillingDisputeRepository extends JpaRepository<BillingDispute, Long> {

    List<BillingDispute> findByConsumer_UserId(Long consumerId);

    List<BillingDispute> findByBill_BillId(Long billId);

    List<BillingDispute> findByStatus(DisputeStatus status);
}
