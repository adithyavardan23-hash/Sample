package com.cts.energygrid.enums;

public enum NotificationCategory {
    BILLING("Billing"),
    PAYMENT("Payment"),
    OUTAGE("Outage"),
    METER("Meter"),
    COMPLIANCE("Compliance");

    private final String displayName;

    NotificationCategory(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
