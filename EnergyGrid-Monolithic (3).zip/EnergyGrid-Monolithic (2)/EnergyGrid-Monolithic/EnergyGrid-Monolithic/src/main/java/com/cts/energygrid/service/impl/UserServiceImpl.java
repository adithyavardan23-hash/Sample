package com.cts.energygrid.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.energygrid.dto.request.UserRequest;
import com.cts.energygrid.dto.response.UserResponse;
import com.cts.energygrid.entity.User;
import com.cts.energygrid.enums.Role;
import com.cts.energygrid.exception.BadRequestException;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.UserRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.UserService;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuditLogService auditLogService;

    // PROBLEM (security) FIX: passwords are now BCrypt-hashed instead of stored plain.
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Override
    public UserResponse register(UserRequest request) {
        validate(request, true);

        // Duplicate-email check: give a clean 400 instead of relying on the DB
        // unique constraint (which would surface as a 409 with no friendly message).
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("Email already registered: " + request.getEmail());
        }

        User user = new User();
        user.setName(request.getName());
        user.setRole(request.getRole());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setPhone(request.getPhone());
        user.setZoneId(request.getZoneId());
        // Default new users to ACTIVE if the caller did not specify a status.
        user.setStatus(request.getStatus() != null ? request.getStatus()
                : com.cts.energygrid.enums.UserStatus.ACTIVE);

        User saved = userRepository.save(user);
        auditLogService.log("CREATE", "User", String.valueOf(saved.getUserId()), saved.getUserId());
        return toResponse(saved);
    }

    @Override
    public UserResponse getUserById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        return toResponse(user);
    }

    @Override
    public List<UserResponse> getAllUsers() {
        return userRepository.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<UserResponse> getUsersByRole(Role role) {
        return userRepository.findByRole(role).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public UserResponse updateUser(Long id, UserRequest request) {
        validate(request, false);

        // PROBLEM 3 FIX: fetch the existing user first, then update its fields
        // (an UPDATE), instead of persisting a brand-new detached entity (an INSERT).
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));

        // If the email is being changed, make sure it does not collide with another user.
        if (request.getEmail() != null && !request.getEmail().equalsIgnoreCase(user.getEmail())
                && userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("Email already registered: " + request.getEmail());
        }

        user.setName(request.getName());
        user.setRole(request.getRole());
        user.setEmail(request.getEmail());
        // Only re-hash the password if a new (non-blank) one was supplied.
        if (request.getPassword() != null && !request.getPassword().isBlank()) {
            user.setPassword(passwordEncoder.encode(request.getPassword()));
        }
        user.setPhone(request.getPhone());
        user.setZoneId(request.getZoneId());
        if (request.getStatus() != null) {
            user.setStatus(request.getStatus());
        }

        User saved = userRepository.save(user);
        auditLogService.log("UPDATE", "User", String.valueOf(id), id);
        return toResponse(saved);
    }

    @Override
    public void deactivateUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        user.setStatus(com.cts.energygrid.enums.UserStatus.INACTIVE);
        userRepository.save(user);
        auditLogService.log("DELETE", "User", String.valueOf(id), id);
    }

    /*
     * Manual request validation. (The project intentionally avoids the
     * spring-boot-starter-validation dependency, so we enforce the key rules here
     * and return a clean 400 via BadRequestException.)
     */
    private void validate(UserRequest request, boolean requirePassword) {
        if (request == null) {
            throw new BadRequestException("Request body is required");
        }
        if (isBlank(request.getName())) {
            throw new BadRequestException("Name is required");
        }
        if (isBlank(request.getEmail())) {
            throw new BadRequestException("Email is required");
        }
        if (request.getRole() == null) {
            throw new BadRequestException("Role is required");
        }
        if (requirePassword && isBlank(request.getPassword())) {
            throw new BadRequestException("Password is required");
        }
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    private UserResponse toResponse(User user) {
        UserResponse response = new UserResponse();
        response.setUserId(user.getUserId());
        response.setName(user.getName());
        response.setRole(user.getRole());
        response.setEmail(user.getEmail());
        response.setPhone(user.getPhone());
        response.setZoneId(user.getZoneId());
        response.setStatus(user.getStatus());
        return response;
    }
}
