package com.cts.energygrid.service;

import java.util.List;

import com.cts.energygrid.dto.request.PaymentRequest;
import com.cts.energygrid.dto.response.PaymentResponse;

public interface PaymentService {

    PaymentResponse recordPayment(PaymentRequest req);

    List<PaymentResponse> getPaymentsByAccount(Long accountId);

    PaymentResponse getPaymentById(Long id);

    List<PaymentResponse> getPaymentsByBill(Long billId);

    List<PaymentResponse> getFailedPayments();

    PaymentResponse retryPayment(Long id);
}
