package com.cts.energygrid.dto.request;

import com.cts.energygrid.enums.AccountStatus;
import com.cts.energygrid.enums.ConnectionType;

public class ConsumerAccountRequest {

    private Long consumerId;
    private String serviceAddress;
    private ConnectionType connectionType;
    private String zoneId;
    private String meterId;
    private AccountStatus status;

    public ConsumerAccountRequest() {
    }

    public ConsumerAccountRequest(Long consumerId, String serviceAddress, ConnectionType connectionType, String zoneId,
            String meterId, AccountStatus status) {
        this.consumerId = consumerId;
        this.serviceAddress = serviceAddress;
        this.connectionType = connectionType;
        this.zoneId = zoneId;
        this.meterId = meterId;
        this.status = status;
    }

    public Long getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(Long consumerId) {
        this.consumerId = consumerId;
    }

    public String getServiceAddress() {
        return serviceAddress;
    }

    public void setServiceAddress(String serviceAddress) {
        this.serviceAddress = serviceAddress;
    }

    public ConnectionType getConnectionType() {
        return connectionType;
    }

    public void setConnectionType(ConnectionType connectionType) {
        this.connectionType = connectionType;
    }

    public String getZoneId() {
        return zoneId;
    }

    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }

    public String getMeterId() {
        return meterId;
    }

    public void setMeterId(String meterId) {
        this.meterId = meterId;
    }

    public AccountStatus getStatus() {
        return status;
    }

    public void setStatus(AccountStatus status) {
        this.status = status;
    }
}
