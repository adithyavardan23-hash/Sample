package com.cts.energygrid.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.energygrid.dto.request.BillRequest;
import com.cts.energygrid.dto.response.BillResponse;
import com.cts.energygrid.enums.BillStatus;
import com.cts.energygrid.service.BillingService;

@RestController
@RequestMapping("/api/bills")
public class BillController {

    @Autowired
    private BillingService billingService;

    @PostMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<BillResponse> generateBill(@RequestBody BillRequest request) {
        return ResponseEntity.ok(billingService.generateBill(request));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','CONSUMER')")
    public ResponseEntity<BillResponse> getBillById(@PathVariable Long id) {
        return ResponseEntity.ok(billingService.getBillById(id));
    }

    @GetMapping("/account/{accountId}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','CONSUMER')")
    public ResponseEntity<List<BillResponse>> getBillsByAccount(@PathVariable Long accountId) {
        return ResponseEntity.ok(billingService.getBillsByAccount(accountId));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<BillResponse> updateStatus(@PathVariable Long id, @RequestParam BillStatus status) {
        return ResponseEntity.ok(billingService.updateStatus(id, status));
    }

    @GetMapping("/overdue")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<List<BillResponse>> getOverdueBills() {
        return ResponseEntity.ok(billingService.getOverdueBills());
    }

    @PatchMapping("/{id}/send")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<BillResponse> sendBill(@PathVariable Long id) {
        return ResponseEntity.ok(billingService.sendBill(id));
    }

    @PatchMapping("/{id}/paid")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<BillResponse> markAsPaid(@PathVariable Long id) {
        return ResponseEntity.ok(billingService.markAsPaid(id));
    }

    @PatchMapping("/{id}/overdue")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<BillResponse> markAsOverdue(@PathVariable Long id) {
        return ResponseEntity.ok(billingService.markAsOverdue(id));
    }

    @GetMapping("/status/{status}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<List<BillResponse>> getBillsByStatus(@PathVariable BillStatus status) {
        return ResponseEntity.ok(billingService.getBillsByStatus(status));
    }
}
