package com.cts.energygrid.enums;

public enum DispatchStatus {
    DISPATCHED("Dispatched"),
    ON_SITE("On Site"),
    RESOLVED("Resolved");

    private final String displayName;

    DispatchStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
