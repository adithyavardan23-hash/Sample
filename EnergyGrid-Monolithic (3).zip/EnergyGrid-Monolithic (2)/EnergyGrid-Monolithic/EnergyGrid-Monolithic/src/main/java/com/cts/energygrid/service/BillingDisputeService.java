package com.cts.energygrid.service;

import java.util.List;

import com.cts.energygrid.dto.request.BillingDisputeRequest;
import com.cts.energygrid.dto.response.BillingDisputeResponse;
import com.cts.energygrid.enums.DisputeStatus;

public interface BillingDisputeService {

    BillingDisputeResponse raiseDispute(BillingDisputeRequest req);

    List<BillingDisputeResponse> getAllDisputes();

    BillingDisputeResponse updateStatus(Long id, DisputeStatus status);

    BillingDisputeResponse getDisputeById(Long id);

    List<BillingDisputeResponse> getDisputesByConsumer(Long consumerId);

    List<BillingDisputeResponse> getDisputesByStatus(DisputeStatus status);

    BillingDisputeResponse reviewDispute(Long id);

    BillingDisputeResponse resolveDispute(Long id);

    BillingDisputeResponse rejectDispute(Long id);
}
