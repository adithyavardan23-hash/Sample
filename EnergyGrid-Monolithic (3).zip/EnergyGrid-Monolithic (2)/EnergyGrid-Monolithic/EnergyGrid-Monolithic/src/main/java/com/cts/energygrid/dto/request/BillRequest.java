package com.cts.energygrid.dto.request;

import java.time.LocalDate;

public class BillRequest {

    private Long accountId;
    private LocalDate billingPeriodStart;
    private LocalDate billingPeriodEnd;
    private Double unitsConsumed;
    private Long tariffId;
    private LocalDate dueDate;

    public BillRequest() {
    }

    public BillRequest(Long accountId, LocalDate billingPeriodStart, LocalDate billingPeriodEnd,
                       Double unitsConsumed, Long tariffId, LocalDate dueDate) {
        this.accountId = accountId;
        this.billingPeriodStart = billingPeriodStart;
        this.billingPeriodEnd = billingPeriodEnd;
        this.unitsConsumed = unitsConsumed;
        this.tariffId = tariffId;
        this.dueDate = dueDate;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public LocalDate getBillingPeriodStart() {
        return billingPeriodStart;
    }

    public void setBillingPeriodStart(LocalDate billingPeriodStart) {
        this.billingPeriodStart = billingPeriodStart;
    }

    public LocalDate getBillingPeriodEnd() {
        return billingPeriodEnd;
    }

    public void setBillingPeriodEnd(LocalDate billingPeriodEnd) {
        this.billingPeriodEnd = billingPeriodEnd;
    }

    public Double getUnitsConsumed() {
        return unitsConsumed;
    }

    public void setUnitsConsumed(Double unitsConsumed) {
        this.unitsConsumed = unitsConsumed;
    }

    public Long getTariffId() {
        return tariffId;
    }

    public void setTariffId(Long tariffId) {
        this.tariffId = tariffId;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }
}
