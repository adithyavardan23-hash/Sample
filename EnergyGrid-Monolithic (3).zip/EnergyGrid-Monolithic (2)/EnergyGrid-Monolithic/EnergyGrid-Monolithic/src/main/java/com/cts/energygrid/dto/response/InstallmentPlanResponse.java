package com.cts.energygrid.dto.response;

import java.time.LocalDate;

import com.cts.energygrid.enums.PlanStatus;

public class InstallmentPlanResponse {

    private Long planId;
    private Long accountId;
    private Double totalDue;
    private Integer installments;
    private LocalDate startDate;
    private LocalDate endDate;
    private PlanStatus status;

    public InstallmentPlanResponse() {
    }

    public InstallmentPlanResponse(Long planId, Long accountId, Double totalDue, Integer installments,
                                   LocalDate startDate, LocalDate endDate, PlanStatus status) {
        this.planId = planId;
        this.accountId = accountId;
        this.totalDue = totalDue;
        this.installments = installments;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
    }

    public Long getPlanId() {
        return planId;
    }

    public void setPlanId(Long planId) {
        this.planId = planId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Double getTotalDue() {
        return totalDue;
    }

    public void setTotalDue(Double totalDue) {
        this.totalDue = totalDue;
    }

    public Integer getInstallments() {
        return installments;
    }

    public void setInstallments(Integer installments) {
        this.installments = installments;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public PlanStatus getStatus() {
        return status;
    }

    public void setStatus(PlanStatus status) {
        this.status = status;
    }
}
