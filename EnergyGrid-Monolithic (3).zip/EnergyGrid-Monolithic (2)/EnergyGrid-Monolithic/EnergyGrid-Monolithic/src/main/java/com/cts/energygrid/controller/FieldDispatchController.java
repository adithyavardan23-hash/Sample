package com.cts.energygrid.controller;

import com.cts.energygrid.dto.request.FieldDispatchRequest;
import com.cts.energygrid.dto.response.FieldDispatchResponse;
import com.cts.energygrid.enums.DispatchStatus;
import com.cts.energygrid.service.FieldDispatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/dispatches")
public class FieldDispatchController {

    @Autowired
    private FieldDispatchService fieldDispatchService;

    @PostMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS')")
    public ResponseEntity<FieldDispatchResponse> dispatchTechnician(@RequestBody FieldDispatchRequest req) {
        return ResponseEntity.ok(fieldDispatchService.dispatchTechnician(req));
    }

    @GetMapping("/outage/{outageId}")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS','FIELD_TECH')")
    public ResponseEntity<List<FieldDispatchResponse>> getDispatchesByOutage(@PathVariable Long outageId) {
        return ResponseEntity.ok(fieldDispatchService.getDispatchesByOutage(outageId));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS','FIELD_TECH')")
    public ResponseEntity<FieldDispatchResponse> updateStatus(@PathVariable Long id,
                                                              @RequestParam DispatchStatus status) {
        return ResponseEntity.ok(fieldDispatchService.updateStatus(id, status));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS','FIELD_TECH')")
    public ResponseEntity<FieldDispatchResponse> getDispatchById(@PathVariable Long id) {
        return ResponseEntity.ok(fieldDispatchService.getDispatchById(id));
    }

    @GetMapping("/technician/{techId}")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS','FIELD_TECH')")
    public ResponseEntity<List<FieldDispatchResponse>> getDispatchesByTechnician(@PathVariable Long techId) {
        return ResponseEntity.ok(fieldDispatchService.getDispatchesByTechnician(techId));
    }

    @PatchMapping("/{id}/onsite")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH')")
    public ResponseEntity<FieldDispatchResponse> markOnSite(@PathVariable Long id) {
        return ResponseEntity.ok(fieldDispatchService.markOnSite(id));
    }

    @PatchMapping("/{id}/resolve")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH')")
    public ResponseEntity<FieldDispatchResponse> markResolved(@PathVariable Long id) {
        return ResponseEntity.ok(fieldDispatchService.markResolved(id));
    }
}
