package com.cts.energygrid.dto.request;

import com.cts.energygrid.enums.Role;
import com.cts.energygrid.enums.UserStatus;

public class UserRequest {

    private String name;
    private Role role;
    private String email;
    private String password;
    private String phone;
    private String zoneId;
    private UserStatus status;
    private Long requesterId;

    public UserRequest() {
    }

    public UserRequest(String name, Role role, String email, String password, String phone, String zoneId,
            UserStatus status, Long requesterId) {
        this.name = name;
        this.role = role;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.zoneId = zoneId;
        this.status = status;
        this.requesterId = requesterId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getZoneId() {
        return zoneId;
    }

    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }

    public UserStatus getStatus() {
        return status;
    }

    public void setStatus(UserStatus status) {
        this.status = status;
    }

    public Long getRequesterId() {
        return requesterId;
    }

    public void setRequesterId(Long requesterId) {
        this.requesterId = requesterId;
    }
}
