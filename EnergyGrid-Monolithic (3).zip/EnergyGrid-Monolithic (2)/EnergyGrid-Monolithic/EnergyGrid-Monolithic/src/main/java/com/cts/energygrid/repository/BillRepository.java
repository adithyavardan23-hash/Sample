package com.cts.energygrid.repository;

import com.cts.energygrid.entity.Bill;
import com.cts.energygrid.enums.BillStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BillRepository extends JpaRepository<Bill, Long> {

    List<Bill> findByAccount_AccountId(Long accountId);

    List<Bill> findByStatus(BillStatus status);
}
