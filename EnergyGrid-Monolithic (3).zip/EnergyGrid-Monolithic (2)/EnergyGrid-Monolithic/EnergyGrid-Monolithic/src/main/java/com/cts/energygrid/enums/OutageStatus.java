package com.cts.energygrid.enums;

public enum OutageStatus {
    ACTIVE("Active"),
    RESTORED("Restored"),
    INVESTIGATING("Investigating");

    private final String displayName;

    OutageStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
