package com.cts.energygrid.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.energygrid.dto.request.BillingDisputeRequest;
import com.cts.energygrid.dto.response.BillingDisputeResponse;
import com.cts.energygrid.enums.DisputeStatus;
import com.cts.energygrid.service.BillingDisputeService;

@RestController
@RequestMapping("/api/disputes")
public class BillingDisputeController {

    @Autowired
    private BillingDisputeService billingDisputeService;

    @PostMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','CONSUMER')")
    public ResponseEntity<BillingDisputeResponse> raiseDispute(@RequestBody BillingDisputeRequest request) {
        return ResponseEntity.ok(billingDisputeService.raiseDispute(request));
    }

    @GetMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','COMPLIANCE')")
    public ResponseEntity<List<BillingDisputeResponse>> getAllDisputes() {
        return ResponseEntity.ok(billingDisputeService.getAllDisputes());
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','COMPLIANCE')")
    public ResponseEntity<BillingDisputeResponse> updateStatus(@PathVariable Long id, @RequestParam DisputeStatus status) {
        return ResponseEntity.ok(billingDisputeService.updateStatus(id, status));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','COMPLIANCE','CONSUMER')")
    public ResponseEntity<BillingDisputeResponse> getDisputeById(@PathVariable Long id) {
        return ResponseEntity.ok(billingDisputeService.getDisputeById(id));
    }

    @GetMapping("/consumer/{consumerId}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','COMPLIANCE','CONSUMER')")
    public ResponseEntity<List<BillingDisputeResponse>> getDisputesByConsumer(@PathVariable Long consumerId) {
        return ResponseEntity.ok(billingDisputeService.getDisputesByConsumer(consumerId));
    }

    @GetMapping("/status/{status}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','COMPLIANCE')")
    public ResponseEntity<List<BillingDisputeResponse>> getDisputesByStatus(@PathVariable DisputeStatus status) {
        return ResponseEntity.ok(billingDisputeService.getDisputesByStatus(status));
    }

    @PatchMapping("/{id}/review")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','COMPLIANCE')")
    public ResponseEntity<BillingDisputeResponse> reviewDispute(@PathVariable Long id) {
        return ResponseEntity.ok(billingDisputeService.reviewDispute(id));
    }

    @PatchMapping("/{id}/resolve")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','COMPLIANCE')")
    public ResponseEntity<BillingDisputeResponse> resolveDispute(@PathVariable Long id) {
        return ResponseEntity.ok(billingDisputeService.resolveDispute(id));
    }

    @PatchMapping("/{id}/reject")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','COMPLIANCE')")
    public ResponseEntity<BillingDisputeResponse> rejectDispute(@PathVariable Long id) {
        return ResponseEntity.ok(billingDisputeService.rejectDispute(id));
    }
}
