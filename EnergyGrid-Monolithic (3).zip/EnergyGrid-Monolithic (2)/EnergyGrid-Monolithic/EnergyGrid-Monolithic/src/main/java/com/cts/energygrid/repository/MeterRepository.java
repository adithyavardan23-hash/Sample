package com.cts.energygrid.repository;

import com.cts.energygrid.entity.Meter;
import com.cts.energygrid.enums.MeterStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface MeterRepository extends JpaRepository<Meter, Long> {

    List<Meter> findByAccount_AccountId(Long accountId);

    List<Meter> findByStatus(MeterStatus status);

    Optional<Meter> findByMeterNumber(String meterNumber);
}
