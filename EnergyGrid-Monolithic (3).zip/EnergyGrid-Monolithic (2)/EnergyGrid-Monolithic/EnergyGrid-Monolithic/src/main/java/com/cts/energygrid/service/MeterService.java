package com.cts.energygrid.service;

import com.cts.energygrid.dto.request.MeterRequest;
import com.cts.energygrid.dto.response.MeterResponse;
import com.cts.energygrid.enums.MeterStatus;
import java.util.List;

public interface MeterService {

    MeterResponse installMeter(MeterRequest req);

    MeterResponse getMeterById(Long id);

    List<MeterResponse> getMetersByAccount(Long accountId);

    MeterResponse updateStatus(Long id, MeterStatus status);

    List<MeterResponse> getFaultyMeters();

    MeterResponse replaceMeter(Long oldMeterId, MeterRequest req);
}
