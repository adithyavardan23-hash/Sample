package com.cts.energygrid.enums;

public enum OutageCause {
    PLANNED("Planned"),
    UNPLANNED("Unplanned"),
    WEATHER("Weather"),
    EQUIPMENT("Equipment Failure");

    private final String displayName;

    OutageCause(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
