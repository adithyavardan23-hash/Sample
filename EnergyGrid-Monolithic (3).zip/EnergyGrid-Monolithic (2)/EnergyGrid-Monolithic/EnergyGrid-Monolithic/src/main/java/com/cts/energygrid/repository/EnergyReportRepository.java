package com.cts.energygrid.repository;

import com.cts.energygrid.entity.EnergyReport;
import com.cts.energygrid.enums.ReportScope;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface EnergyReportRepository extends JpaRepository<EnergyReport, Long> {

    List<EnergyReport> findByScope(ReportScope scope);

    List<EnergyReport> findByGeneratedDateBetween(LocalDateTime from, LocalDateTime to);
}
