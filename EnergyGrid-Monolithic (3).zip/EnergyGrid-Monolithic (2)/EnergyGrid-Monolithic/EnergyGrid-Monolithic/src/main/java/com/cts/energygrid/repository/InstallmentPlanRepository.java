package com.cts.energygrid.repository;

import com.cts.energygrid.entity.InstallmentPlan;
import com.cts.energygrid.enums.PlanStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface InstallmentPlanRepository extends JpaRepository<InstallmentPlan, Long> {

    List<InstallmentPlan> findByAccount_AccountId(Long accountId);

    List<InstallmentPlan> findByStatus(PlanStatus status);
}
