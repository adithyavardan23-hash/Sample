package com.cts.energygrid.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(LoggingAspect.class);

    @Before("execution(* com.cts.energygrid.service.impl.*.*(..)) && !within(com.cts.energygrid.service.impl.AuditLogServiceImpl)")
    public void logBefore(JoinPoint jp) {
        logger.info("Entering method: {} with args: {}", jp.getSignature().getName(),
                java.util.Arrays.toString(jp.getArgs()));
    }

    @AfterReturning(pointcut = "execution(* com.cts.energygrid.service.impl.*.*(..)) && !within(com.cts.energygrid.service.impl.AuditLogServiceImpl)", returning = "result")
    public void logAfter(JoinPoint jp, Object result) {
        logger.info("Exiting method: {} with result: {}", jp.getSignature().getName(), result);
    }
}
