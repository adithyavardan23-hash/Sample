package com.cts.energygrid.dto.response;

import java.time.LocalDate;

import com.cts.energygrid.enums.PaymentMethod;
import com.cts.energygrid.enums.PaymentStatus;

public class PaymentResponse {

    private Long paymentId;
    private Long billId;
    private Long accountId;
    private Double amount;
    private LocalDate paymentDate;
    private PaymentMethod method;
    private PaymentStatus status;

    public PaymentResponse() {
    }

    public PaymentResponse(Long paymentId, Long billId, Long accountId, Double amount,
                           LocalDate paymentDate, PaymentMethod method, PaymentStatus status) {
        this.paymentId = paymentId;
        this.billId = billId;
        this.accountId = accountId;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.method = method;
        this.status = status;
    }

    public Long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = paymentDate;
    }

    public PaymentMethod getMethod() {
        return method;
    }

    public void setMethod(PaymentMethod method) {
        this.method = method;
    }

    public PaymentStatus getStatus() {
        return status;
    }

    public void setStatus(PaymentStatus status) {
        this.status = status;
    }
}
