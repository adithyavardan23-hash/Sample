package com.cts.energygrid.service.impl;

import com.cts.energygrid.dto.request.MeterReadingRequest;
import com.cts.energygrid.dto.response.MeterReadingResponse;
import com.cts.energygrid.entity.Meter;
import com.cts.energygrid.entity.MeterReading;
import com.cts.energygrid.enums.ReadingStatus;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.MeterReadingRepository;
import com.cts.energygrid.repository.MeterRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.MeterReadingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MeterReadingServiceImpl implements MeterReadingService {

    @Autowired
    private MeterReadingRepository meterReadingRepository;

    @Autowired
    private MeterRepository meterRepository;

    @Autowired
    private AuditLogService auditLogService;

    @Override
    public MeterReadingResponse addReading(MeterReadingRequest req) {
        Meter meter = meterRepository.findById(req.getMeterId())
                .orElseThrow(() -> new ResourceNotFoundException("Meter not found with id: " + req.getMeterId()));

        MeterReading reading = new MeterReading();
        reading.setMeter(meter);
        reading.setReadingValue(req.getReadingValue());
        reading.setReadingDate(req.getReadingDate());
        reading.setSource(req.getSource());
        reading.setStatus(req.getStatus());

        MeterReading saved = meterReadingRepository.save(reading);
        auditLogService.log("CREATE", "MeterReading", String.valueOf(saved.getReadingId()), saved.getReadingId());
        return mapToResponse(saved);
    }

    @Override
    public List<MeterReadingResponse> getReadingsByMeter(Long meterId) {
        return meterReadingRepository.findByMeter_MeterId(meterId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public MeterReadingResponse getLatestReading(Long meterId) {
        List<MeterReading> readings = meterReadingRepository.findByMeter_MeterIdOrderByReadingDateDesc(meterId);
        if (readings.isEmpty()) {
            throw new ResourceNotFoundException("No readings found for meter id: " + meterId);
        }
        return mapToResponse(readings.get(0));
    }

    @Override
    public List<MeterReadingResponse> getReadingsForPeriod(Long meterId, LocalDate start, LocalDate end) {
        return meterReadingRepository.findByMeter_MeterIdAndReadingDateBetween(meterId, start, end).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public MeterReadingResponse validateReading(Long id) {
        MeterReading reading = meterReadingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Reading not found with id: " + id));
        reading.setStatus(ReadingStatus.VALIDATED);
        MeterReading saved = meterReadingRepository.save(reading);
        auditLogService.log("UPDATE", "MeterReading", String.valueOf(saved.getReadingId()), saved.getReadingId());
        return mapToResponse(saved);
    }

    @Override
    public MeterReadingResponse disputeReading(Long id) {
        MeterReading reading = meterReadingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Reading not found with id: " + id));
        reading.setStatus(ReadingStatus.DISPUTED);
        MeterReading saved = meterReadingRepository.save(reading);
        auditLogService.log("UPDATE", "MeterReading", String.valueOf(saved.getReadingId()), saved.getReadingId());
        return mapToResponse(saved);
    }

    private MeterReadingResponse mapToResponse(MeterReading reading) {
        Long meterId = reading.getMeter() != null ? reading.getMeter().getMeterId() : null;
        return new MeterReadingResponse(
                reading.getReadingId(),
                meterId,
                reading.getReadingValue(),
                reading.getReadingDate(),
                reading.getSource(),
                reading.getStatus()
        );
    }
}
