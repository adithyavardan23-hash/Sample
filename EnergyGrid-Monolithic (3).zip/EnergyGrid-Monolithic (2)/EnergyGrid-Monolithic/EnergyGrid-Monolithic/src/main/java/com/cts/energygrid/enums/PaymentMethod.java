package com.cts.energygrid.enums;

public enum PaymentMethod {
    ONLINE("Online"),
    CASH("Cash"),
    CHEQUE("Cheque"),
    AUTO_DEBIT("Auto Debit");

    private final String displayName;

    PaymentMethod(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
