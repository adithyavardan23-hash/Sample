package com.cts.energygrid.repository;

import java.time.LocalDateTime;
import java.util.List;

import com.cts.energygrid.entity.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;

/*
 * PROBLEM 6 FIX:
 * Added derived queries to back the new filter endpoints. The audit user is
 * stored as `performedBy` on the entity, so the "by user" finder uses that field.
 */
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

    List<AuditLog> findByPerformedBy(Long performedBy);

    List<AuditLog> findByAction(String action);

    List<AuditLog> findByTimestampBetween(LocalDateTime from, LocalDateTime to);
}
