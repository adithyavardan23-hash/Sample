package com.cts.energygrid.repository;

import com.cts.energygrid.entity.OutageEvent;
import com.cts.energygrid.enums.OutageStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OutageEventRepository extends JpaRepository<OutageEvent, Long> {

    List<OutageEvent> findByStatus(OutageStatus status);

    List<OutageEvent> findByZoneId(String zoneId);
}
