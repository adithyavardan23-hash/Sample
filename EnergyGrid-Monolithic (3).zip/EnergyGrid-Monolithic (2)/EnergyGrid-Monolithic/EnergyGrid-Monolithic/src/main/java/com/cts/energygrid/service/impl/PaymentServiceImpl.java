package com.cts.energygrid.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.energygrid.dto.request.PaymentRequest;
import com.cts.energygrid.dto.response.PaymentResponse;
import com.cts.energygrid.entity.Bill;
import com.cts.energygrid.entity.ConsumerAccount;
import com.cts.energygrid.entity.Payment;
import com.cts.energygrid.enums.BillStatus;
import com.cts.energygrid.enums.PaymentStatus;
import com.cts.energygrid.exception.BadRequestException;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.BillRepository;
import com.cts.energygrid.repository.ConsumerAccountRepository;
import com.cts.energygrid.repository.PaymentRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private BillRepository billRepository;

    @Autowired
    private ConsumerAccountRepository consumerAccountRepository;

    @Autowired
    private AuditLogService auditLogService;

    @Override
    public PaymentResponse recordPayment(PaymentRequest req) {
        Bill bill = billRepository.findById(req.getBillId())
                .orElseThrow(() -> new ResourceNotFoundException("Bill not found with id: " + req.getBillId()));
        ConsumerAccount account = consumerAccountRepository.findById(req.getAccountId())
                .orElseThrow(() -> new ResourceNotFoundException("ConsumerAccount not found with id: " + req.getAccountId()));

        if (bill.getStatus() == BillStatus.PAID) {
            throw new BadRequestException("Bill is already paid");
        }

        Payment payment = new Payment();
        payment.setBill(bill);
        payment.setAccount(account);
        payment.setAmount(req.getAmount());
        payment.setPaymentDate(req.getPaymentDate());
        payment.setMethod(req.getMethod());
        payment.setStatus(PaymentStatus.RECEIVED);

        Payment saved = paymentRepository.save(payment);

        bill.setStatus(BillStatus.PAID);
        billRepository.save(bill);

        auditLogService.log("PAYMENT_RECEIVED", "Payment", String.valueOf(saved.getPaymentId()), account.getAccountId());
        return mapToResponse(saved);
    }

    @Override
    public List<PaymentResponse> getPaymentsByAccount(Long accountId) {
        return paymentRepository.findByAccount_AccountId(accountId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public PaymentResponse getPaymentById(Long id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found with id: " + id));
        return mapToResponse(payment);
    }

    @Override
    public List<PaymentResponse> getPaymentsByBill(Long billId) {
        return paymentRepository.findByBill_BillId(billId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<PaymentResponse> getFailedPayments() {
        return paymentRepository.findByStatus(PaymentStatus.FAILED).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public PaymentResponse retryPayment(Long id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found with id: " + id));
        if (payment.getStatus() != PaymentStatus.FAILED) {
            throw new BadRequestException("Only failed payments can be retried");
        }
        payment.setStatus(PaymentStatus.RECEIVED);
        Payment saved = paymentRepository.save(payment);
        auditLogService.log("PAYMENT_RECEIVED", "Payment", String.valueOf(saved.getPaymentId()),
                saved.getAccount() != null ? saved.getAccount().getAccountId() : null);
        return mapToResponse(saved);
    }

    private PaymentResponse mapToResponse(Payment payment) {
        return new PaymentResponse(
                payment.getPaymentId(),
                payment.getBill() != null ? payment.getBill().getBillId() : null,
                payment.getAccount() != null ? payment.getAccount().getAccountId() : null,
                payment.getAmount(),
                payment.getPaymentDate(),
                payment.getMethod(),
                payment.getStatus());
    }
}
