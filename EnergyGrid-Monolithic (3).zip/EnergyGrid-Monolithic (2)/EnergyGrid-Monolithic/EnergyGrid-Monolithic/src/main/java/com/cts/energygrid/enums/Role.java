package com.cts.energygrid.enums;

public enum Role {
    CONSUMER("Consumer"),
    FIELD_TECH("Field Technician"),
    BILLING("Billing Executive"),
    GRID_OPS("Grid Operations Analyst"),
    COMPLIANCE("Compliance Officer"),
    ADMIN("Administrator");

    private final String displayName;

    Role(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
