package com.cts.energygrid.dto.response;

import com.cts.energygrid.enums.AccountStatus;
import com.cts.energygrid.enums.ConnectionType;

public class ConsumerAccountResponse {

    private Long accountId;
    private Long consumerId;
    private String serviceAddress;
    private ConnectionType connectionType;
    private String zoneId;
    private String meterId;
    private AccountStatus status;

    public ConsumerAccountResponse() {
    }

    public ConsumerAccountResponse(Long accountId, Long consumerId, String serviceAddress,
            ConnectionType connectionType, String zoneId, String meterId, AccountStatus status) {
        this.accountId = accountId;
        this.consumerId = consumerId;
        this.serviceAddress = serviceAddress;
        this.connectionType = connectionType;
        this.zoneId = zoneId;
        this.meterId = meterId;
        this.status = status;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Long getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(Long consumerId) {
        this.consumerId = consumerId;
    }

    public String getServiceAddress() {
        return serviceAddress;
    }

    public void setServiceAddress(String serviceAddress) {
        this.serviceAddress = serviceAddress;
    }

    public ConnectionType getConnectionType() {
        return connectionType;
    }

    public void setConnectionType(ConnectionType connectionType) {
        this.connectionType = connectionType;
    }

    public String getZoneId() {
        return zoneId;
    }

    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }

    public String getMeterId() {
        return meterId;
    }

    public void setMeterId(String meterId) {
        this.meterId = meterId;
    }

    public AccountStatus getStatus() {
        return status;
    }

    public void setStatus(AccountStatus status) {
        this.status = status;
    }
}
