package com.cts.energygrid.service;

import java.util.List;

import com.cts.energygrid.dto.request.InstallmentPlanRequest;
import com.cts.energygrid.dto.response.InstallmentPlanResponse;
import com.cts.energygrid.enums.PlanStatus;

public interface InstallmentPlanService {

    InstallmentPlanResponse createPlan(InstallmentPlanRequest req);

    List<InstallmentPlanResponse> getPlansByAccount(Long accountId);

    InstallmentPlanResponse updateStatus(Long id, PlanStatus status);

    InstallmentPlanResponse getPlanById(Long id);

    List<InstallmentPlanResponse> getActivePlans();

    InstallmentPlanResponse markPlanCompleted(Long id);

    InstallmentPlanResponse markPlanDefaulted(Long id);
}
