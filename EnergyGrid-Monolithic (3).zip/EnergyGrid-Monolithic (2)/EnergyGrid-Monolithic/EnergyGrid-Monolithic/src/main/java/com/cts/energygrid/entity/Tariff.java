package com.cts.energygrid.entity;

import com.cts.energygrid.enums.ConsumerCategory;
import com.cts.energygrid.enums.TariffStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "tariffs")
public class Tariff {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long tariffId;

    private String name;

    @Enumerated(EnumType.STRING)
    @Column
    private ConsumerCategory consumerCategory;

    private String slabRates;

    private Double fixedCharges;

    private Double taxRates;

    private LocalDate effectiveDate;

    @Enumerated(EnumType.STRING)
    @Column
    private TariffStatus status;

    public Tariff() {
    }

    public Long getTariffId() {
        return tariffId;
    }

    public void setTariffId(Long tariffId) {
        this.tariffId = tariffId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ConsumerCategory getConsumerCategory() {
        return consumerCategory;
    }

    public void setConsumerCategory(ConsumerCategory consumerCategory) {
        this.consumerCategory = consumerCategory;
    }

    public String getSlabRates() {
        return slabRates;
    }

    public void setSlabRates(String slabRates) {
        this.slabRates = slabRates;
    }

    public Double getFixedCharges() {
        return fixedCharges;
    }

    public void setFixedCharges(Double fixedCharges) {
        this.fixedCharges = fixedCharges;
    }

    public Double getTaxRates() {
        return taxRates;
    }

    public void setTaxRates(Double taxRates) {
        this.taxRates = taxRates;
    }

    public LocalDate getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public TariffStatus getStatus() {
        return status;
    }

    public void setStatus(TariffStatus status) {
        this.status = status;
    }
}
