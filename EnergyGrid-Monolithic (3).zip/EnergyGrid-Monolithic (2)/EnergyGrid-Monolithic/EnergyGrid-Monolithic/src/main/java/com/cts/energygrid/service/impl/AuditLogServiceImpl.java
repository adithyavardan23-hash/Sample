package com.cts.energygrid.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.energygrid.dto.response.AuditLogResponse;
import com.cts.energygrid.entity.AuditLog;
import com.cts.energygrid.repository.AuditLogRepository;
import com.cts.energygrid.repository.UserRepository;
import com.cts.energygrid.service.AuditLogService;

/*
 * NOTE: This impl is intentionally EXCLUDED from LoggingAspect's pointcut, so
 * injecting UserRepository here does not create logging recursion.
 */
@Service
public class AuditLogServiceImpl implements AuditLogService {

    // Project uses plain SLF4J (no Lombok), matching LoggingAspect's style.
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(AuditLogServiceImpl.class);

    @Autowired
    private AuditLogRepository auditLogRepository;

    // Needed to enrich each log with the acting user's name/email.
    @Autowired
    private UserRepository userRepository;

    /*
     * SHARED METHOD — unchanged behaviour. Persists an audit record.
     */
    @Override
    public void log(String action, String entityType, String entityId, Long performedBy) {
        AuditLog auditLog = new AuditLog();
        auditLog.setAction(action);
        auditLog.setEntityType(entityType);
        auditLog.setEntityId(entityId);
        auditLog.setPerformedBy(performedBy);
        auditLog.setTimestamp(LocalDateTime.now());
        auditLogRepository.save(auditLog);
    }

    // PROBLEM 5 FIX: map entities to DTOs before returning.
    @Override
    public List<AuditLogResponse> getAllLogs() {
        return auditLogRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    // PROBLEM 6 FIX: filter by acting user.
    @Override
    public List<AuditLogResponse> getLogsByUserId(Long userId) {
        return auditLogRepository.findByPerformedBy(userId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    // PROBLEM 6 FIX: filter by action.
    @Override
    public List<AuditLogResponse> getLogsByAction(String action) {
        return auditLogRepository.findByAction(action).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    // PROBLEM 6 FIX: filter by timestamp range.
    @Override
    public List<AuditLogResponse> getLogsByDateRange(LocalDateTime from, LocalDateTime to) {
        return auditLogRepository.findByTimestampBetween(from, to).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    /*
     * PROBLEM 5 FIX (mapper):
     * Resolves the acting user (performedBy) into name/email with NULL CHECKS so
     * a missing/deleted user never causes a NullPointerException — those fields
     * simply stay null in the response.
     */
    private AuditLogResponse mapToResponse(AuditLog entry) {
        AuditLogResponse dto = new AuditLogResponse();
        dto.setAuditId(entry.getAuditId());
        dto.setAction(entry.getAction());
        dto.setEntityType(entry.getEntityType());
        dto.setEntityId(entry.getEntityId());
        dto.setTimestamp(entry.getTimestamp());

        Long performedBy = entry.getPerformedBy();
        dto.setUserId(performedBy);
        if (performedBy != null) {
            userRepository.findById(performedBy).ifPresentOrElse(
                    user -> {
                        dto.setUserName(user.getName());
                        dto.setUserEmail(user.getEmail());
                    },
                    () -> log.warn("Audit log {} references unknown userId {}", entry.getAuditId(), performedBy));
        }
        return dto;
    }
}
