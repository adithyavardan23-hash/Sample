package com.cts.energygrid.repository;

import java.util.List;

import com.cts.energygrid.entity.ConnectionRequest;
import com.cts.energygrid.enums.RequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConnectionRequestRepository extends JpaRepository<ConnectionRequest, Long> {

    List<ConnectionRequest> findByConsumer_UserId(Long consumerId);

    List<ConnectionRequest> findByStatus(RequestStatus status);

    List<ConnectionRequest> findByAssignedTechId(Long techId);
}
