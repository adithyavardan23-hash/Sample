package com.cts.energygrid.enums;

public enum ReadingSource {
    MANUAL("Manual"),
    AMI("AMI"),
    ESTIMATED("Estimated");

    private final String displayName;

    ReadingSource(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
