package com.cts.energygrid.enums;

public enum NotificationStatus {
    UNREAD("Unread"),
    READ("Read"),
    DISMISSED("Dismissed");

    private final String displayName;

    NotificationStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
