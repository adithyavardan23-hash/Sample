package com.cts.energygrid.controller;

import com.cts.energygrid.dto.request.MeterRequest;
import com.cts.energygrid.dto.response.MeterResponse;
import com.cts.energygrid.enums.MeterStatus;
import com.cts.energygrid.service.MeterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/meters")
public class MeterController {

    @Autowired
    private MeterService meterService;

    @PostMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH')")
    public ResponseEntity<MeterResponse> installMeter(@RequestBody MeterRequest req) {
        return ResponseEntity.ok(meterService.installMeter(req));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH','GRID_OPS','CONSUMER')")
    public ResponseEntity<MeterResponse> getMeterById(@PathVariable Long id) {
        return ResponseEntity.ok(meterService.getMeterById(id));
    }

    @GetMapping("/account/{accountId}")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH','GRID_OPS','CONSUMER')")
    public ResponseEntity<List<MeterResponse>> getMetersByAccount(@PathVariable Long accountId) {
        return ResponseEntity.ok(meterService.getMetersByAccount(accountId));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH')")
    public ResponseEntity<MeterResponse> updateStatus(@PathVariable Long id, @RequestParam MeterStatus status) {
        return ResponseEntity.ok(meterService.updateStatus(id, status));
    }

    @GetMapping("/faulty")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH','GRID_OPS')")
    public ResponseEntity<List<MeterResponse>> getFaultyMeters() {
        return ResponseEntity.ok(meterService.getFaultyMeters());
    }

    @PutMapping("/{id}/replace")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH')")
    public ResponseEntity<MeterResponse> replaceMeter(@PathVariable Long id, @RequestBody MeterRequest req) {
        return ResponseEntity.ok(meterService.replaceMeter(id, req));
    }
}
