package com.cts.energygrid.enums;

public enum PlanStatus {
    ACTIVE("Active"),
    COMPLETED("Completed"),
    DEFAULTED("Defaulted");

    private final String displayName;

    PlanStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
