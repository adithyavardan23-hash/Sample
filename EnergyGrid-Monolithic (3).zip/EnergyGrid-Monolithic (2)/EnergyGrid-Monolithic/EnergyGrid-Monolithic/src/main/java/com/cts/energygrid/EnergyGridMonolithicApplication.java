package com.cts.energygrid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnergyGridMonolithicApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnergyGridMonolithicApplication.class, args);
	}

}
