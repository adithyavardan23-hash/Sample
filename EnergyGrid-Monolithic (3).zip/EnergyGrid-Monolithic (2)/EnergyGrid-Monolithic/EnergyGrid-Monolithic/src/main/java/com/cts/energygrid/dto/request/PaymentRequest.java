package com.cts.energygrid.dto.request;

import java.time.LocalDate;

import com.cts.energygrid.enums.PaymentMethod;

public class PaymentRequest {

    private Long billId;
    private Long accountId;
    private Double amount;
    private LocalDate paymentDate;
    private PaymentMethod method;

    public PaymentRequest() {
    }

    public PaymentRequest(Long billId, Long accountId, Double amount, LocalDate paymentDate, PaymentMethod method) {
        this.billId = billId;
        this.accountId = accountId;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.method = method;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = paymentDate;
    }

    public PaymentMethod getMethod() {
        return method;
    }

    public void setMethod(PaymentMethod method) {
        this.method = method;
    }
}
