package com.cts.energygrid.enums;

public enum RequestType {
    NEW_CONNECTION("New Connection"),
    UPGRADE("Upgrade"),
    DISCONNECTION("Disconnection"),
    RECONNECTION("Reconnection");

    private final String displayName;

    RequestType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
