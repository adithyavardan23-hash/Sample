package com.cts.energygrid.enums;

public enum RequestStatus {
    PENDING("Pending"),
    SCHEDULED("Scheduled"),
    COMPLETED("Completed"),
    REJECTED("Rejected");

    private final String displayName;

    RequestStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
