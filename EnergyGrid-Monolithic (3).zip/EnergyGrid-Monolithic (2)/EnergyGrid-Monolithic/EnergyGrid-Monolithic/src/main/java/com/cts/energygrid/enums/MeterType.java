package com.cts.energygrid.enums;

public enum MeterType {
    ANALOG("Analog"),
    DIGITAL("Digital"),
    SMART_AMI("Smart AMI");

    private final String displayName;

    MeterType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
