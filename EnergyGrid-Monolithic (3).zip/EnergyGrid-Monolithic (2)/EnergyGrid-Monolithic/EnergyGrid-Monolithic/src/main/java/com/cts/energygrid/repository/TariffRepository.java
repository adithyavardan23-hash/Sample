package com.cts.energygrid.repository;

import com.cts.energygrid.entity.Tariff;
import com.cts.energygrid.enums.ConsumerCategory;
import com.cts.energygrid.enums.TariffStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface TariffRepository extends JpaRepository<Tariff, Long> {

    List<Tariff> findByConsumerCategory(ConsumerCategory category);

    Optional<Tariff> findByConsumerCategoryAndStatus(ConsumerCategory category, TariffStatus status);
}
