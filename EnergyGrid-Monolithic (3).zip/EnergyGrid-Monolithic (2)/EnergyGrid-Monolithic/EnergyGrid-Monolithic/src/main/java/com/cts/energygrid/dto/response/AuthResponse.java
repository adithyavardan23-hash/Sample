package com.cts.energygrid.dto.response;

/*
 * PROBLEM 1 FIX:
 * AuthResponse previously returned ONLY the token, so the frontend could not
 * do a role-based redirect or know which userId to use for subsequent calls.
 * We now also expose `role` and `userId`.
 * Style kept manual (no Lombok) to match the existing DTOs in this package.
 */
public class AuthResponse {

    private String token;
    private String role;
    private Long userId;

    public AuthResponse() {
    }

    // Kept for backward compatibility with any caller that only had a token.
    public AuthResponse(String token) {
        this.token = token;
    }

    // New full constructor used by AuthServiceImpl.login(...)
    public AuthResponse(String token, String role, Long userId) {
        this.token = token;
        this.role = role;
        this.userId = userId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
