package com.cts.energygrid.enums;

public enum BillStatus {
    GENERATED("Generated"),
    SENT("Sent"),
    PAID("Paid"),
    OVERDUE("Overdue"),
    DISPUTED("Disputed");

    private final String displayName;

    BillStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
