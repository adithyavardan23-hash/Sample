package com.cts.energygrid.dto.request;

import com.cts.energygrid.enums.NotificationCategory;

public class NotificationRequest {

    private Long userId;
    private String message;
    private NotificationCategory category;

    public NotificationRequest() {
    }

    public NotificationRequest(Long userId, String message, NotificationCategory category) {
        this.userId = userId;
        this.message = message;
        this.category = category;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public NotificationCategory getCategory() {
        return category;
    }

    public void setCategory(NotificationCategory category) {
        this.category = category;
    }
}
