package com.cts.energygrid.dto.response;

import com.cts.energygrid.enums.Role;
import com.cts.energygrid.enums.UserStatus;

public class UserResponse {

    private Long userId;
    private String name;
    private Role role;
    private String email;
    private String phone;
    private String zoneId;
    private UserStatus status;

    public UserResponse() {
    }

    public UserResponse(Long userId, String name, Role role, String email, String phone, String zoneId,
            UserStatus status) {
        this.userId = userId;
        this.name = name;
        this.role = role;
        this.email = email;
        this.phone = phone;
        this.zoneId = zoneId;
        this.status = status;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getZoneId() {
        return zoneId;
    }

    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }

    public UserStatus getStatus() {
        return status;
    }

    public void setStatus(UserStatus status) {
        this.status = status;
    }
}
