package com.cts.energygrid.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.energygrid.dto.request.ConnectionRequestRequest;
import com.cts.energygrid.dto.response.ConnectionRequestResponse;
import com.cts.energygrid.enums.RequestStatus;
import com.cts.energygrid.service.ConnectionRequestService;

@RestController
@RequestMapping("/api/connections")
public class ConnectionRequestController {

    @Autowired
    private ConnectionRequestService connectionRequestService;

    @PostMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','CONSUMER')")
    public ResponseEntity<ConnectionRequestResponse> submitRequest(@RequestBody ConnectionRequestRequest req) {
        return ResponseEntity.ok(connectionRequestService.submitRequest(req));
    }

    @GetMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH')")
    public ResponseEntity<List<ConnectionRequestResponse>> getAllRequests() {
        return ResponseEntity.ok(connectionRequestService.getAllRequests());
    }

    @PatchMapping("/{id}/assign")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ConnectionRequestResponse> assignTechnician(@PathVariable Long id,
            @RequestParam Long techId) {
        return ResponseEntity.ok(connectionRequestService.assignTechnician(id, techId));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH')")
    public ResponseEntity<ConnectionRequestResponse> updateStatus(@PathVariable Long id,
            @RequestParam RequestStatus status) {
        return ResponseEntity.ok(connectionRequestService.updateStatus(id, status));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH','CONSUMER')")
    public ResponseEntity<ConnectionRequestResponse> getRequestById(@PathVariable Long id) {
        return ResponseEntity.ok(connectionRequestService.getRequestById(id));
    }

    @GetMapping("/consumer/{consumerId}")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH','CONSUMER')")
    public ResponseEntity<List<ConnectionRequestResponse>> getRequestsByConsumer(@PathVariable Long consumerId) {
        return ResponseEntity.ok(connectionRequestService.getRequestsByConsumer(consumerId));
    }

    @GetMapping("/pending")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH')")
    public ResponseEntity<List<ConnectionRequestResponse>> getPendingRequests() {
        return ResponseEntity.ok(connectionRequestService.getPendingRequests());
    }
}
