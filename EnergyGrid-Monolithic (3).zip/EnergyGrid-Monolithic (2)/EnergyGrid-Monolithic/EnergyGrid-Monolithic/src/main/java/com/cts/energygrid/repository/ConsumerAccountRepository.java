package com.cts.energygrid.repository;

import java.util.List;

import com.cts.energygrid.entity.ConsumerAccount;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsumerAccountRepository extends JpaRepository<ConsumerAccount, Long> {

    List<ConsumerAccount> findByConsumer_UserId(Long consumerId);

    List<ConsumerAccount> findByZoneId(String zoneId);
}
