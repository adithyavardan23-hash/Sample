package com.cts.energygrid.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.energygrid.dto.request.ConsumerAccountRequest;
import com.cts.energygrid.dto.response.ConsumerAccountResponse;
import com.cts.energygrid.entity.ConsumerAccount;
import com.cts.energygrid.entity.User;
import com.cts.energygrid.enums.AccountStatus;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.ConsumerAccountRepository;
import com.cts.energygrid.repository.UserRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.ConsumerAccountService;

@Service
public class ConsumerAccountServiceImpl implements ConsumerAccountService {

    @Autowired
    private ConsumerAccountRepository consumerAccountRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuditLogService auditLogService;

    @Override
    public ConsumerAccountResponse createAccount(ConsumerAccountRequest req) {
        User consumer = userRepository.findById(req.getConsumerId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + req.getConsumerId()));

        ConsumerAccount account = new ConsumerAccount();
        account.setConsumer(consumer);
        account.setServiceAddress(req.getServiceAddress());
        account.setConnectionType(req.getConnectionType());
        account.setZoneId(req.getZoneId());
        account.setMeterId(req.getMeterId());
        account.setStatus(req.getStatus());

        ConsumerAccount saved = consumerAccountRepository.save(account);
        auditLogService.log("CREATE", "ConsumerAccount", String.valueOf(saved.getAccountId()), consumer.getUserId());
        return toResponse(saved);
    }

    @Override
    public ConsumerAccountResponse getAccountById(Long id) {
        ConsumerAccount account = consumerAccountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ConsumerAccount not found with id: " + id));
        return toResponse(account);
    }

    @Override
    public List<ConsumerAccountResponse> getAllAccounts() {
        return consumerAccountRepository.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public ConsumerAccountResponse updateStatus(Long id, AccountStatus status) {
        ConsumerAccount account = consumerAccountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ConsumerAccount not found with id: " + id));
        account.setStatus(status);
        ConsumerAccount saved = consumerAccountRepository.save(account);
        auditLogService.log("UPDATE", "ConsumerAccount", String.valueOf(id), id);
        return toResponse(saved);
    }

    @Override
    public ConsumerAccountResponse getAccountByConsumerId(Long consumerId) {
        List<ConsumerAccount> accounts = consumerAccountRepository.findByConsumer_UserId(consumerId);
        if (accounts.isEmpty()) {
            throw new ResourceNotFoundException("Account not found for consumer id: " + consumerId);
        }
        return toResponse(accounts.get(0));
    }

    @Override
    public List<ConsumerAccountResponse> getAccountsByZone(String zoneId) {
        return consumerAccountRepository.findByZoneId(zoneId).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public ConsumerAccountResponse updateAccount(Long id, ConsumerAccountRequest req) {
        ConsumerAccount account = consumerAccountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ConsumerAccount not found with id: " + id));
        if (req.getServiceAddress() != null) {
            account.setServiceAddress(req.getServiceAddress());
        }
        if (req.getConnectionType() != null) {
            account.setConnectionType(req.getConnectionType());
        }
        if (req.getZoneId() != null) {
            account.setZoneId(req.getZoneId());
        }
        if (req.getMeterId() != null) {
            account.setMeterId(req.getMeterId());
        }
        if (req.getStatus() != null) {
            account.setStatus(req.getStatus());
        }
        ConsumerAccount saved = consumerAccountRepository.save(account);
        auditLogService.log("UPDATE", "ConsumerAccount", String.valueOf(id),
                account.getConsumer() != null ? account.getConsumer().getUserId() : null);
        return toResponse(saved);
    }

    @Override
    public ConsumerAccountResponse suspendAccount(Long id) {
        ConsumerAccount account = consumerAccountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ConsumerAccount not found with id: " + id));
        account.setStatus(AccountStatus.SUSPENDED);
        ConsumerAccount saved = consumerAccountRepository.save(account);
        auditLogService.log("UPDATE", "ConsumerAccount", String.valueOf(id),
                account.getConsumer() != null ? account.getConsumer().getUserId() : null);
        return toResponse(saved);
    }

    @Override
    public ConsumerAccountResponse disconnectAccount(Long id) {
        ConsumerAccount account = consumerAccountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ConsumerAccount not found with id: " + id));
        account.setStatus(AccountStatus.DISCONNECTED);
        ConsumerAccount saved = consumerAccountRepository.save(account);
        auditLogService.log("UPDATE", "ConsumerAccount", String.valueOf(id),
                account.getConsumer() != null ? account.getConsumer().getUserId() : null);
        return toResponse(saved);
    }

    @Override
    public ConsumerAccountResponse reactivateAccount(Long id) {
        ConsumerAccount account = consumerAccountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ConsumerAccount not found with id: " + id));
        account.setStatus(AccountStatus.ACTIVE);
        ConsumerAccount saved = consumerAccountRepository.save(account);
        auditLogService.log("UPDATE", "ConsumerAccount", String.valueOf(id),
                account.getConsumer() != null ? account.getConsumer().getUserId() : null);
        return toResponse(saved);
    }

    private ConsumerAccountResponse toResponse(ConsumerAccount account) {
        ConsumerAccountResponse response = new ConsumerAccountResponse();
        response.setAccountId(account.getAccountId());
        response.setConsumerId(account.getConsumer() != null ? account.getConsumer().getUserId() : null);
        response.setServiceAddress(account.getServiceAddress());
        response.setConnectionType(account.getConnectionType());
        response.setZoneId(account.getZoneId());
        response.setMeterId(account.getMeterId());
        response.setStatus(account.getStatus());
        return response;
    }
}
