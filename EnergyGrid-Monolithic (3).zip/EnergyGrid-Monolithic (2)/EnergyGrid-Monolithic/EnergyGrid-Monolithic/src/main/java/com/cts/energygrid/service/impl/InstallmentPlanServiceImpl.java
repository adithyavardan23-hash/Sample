package com.cts.energygrid.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.energygrid.dto.request.InstallmentPlanRequest;
import com.cts.energygrid.dto.response.InstallmentPlanResponse;
import com.cts.energygrid.entity.ConsumerAccount;
import com.cts.energygrid.entity.InstallmentPlan;
import com.cts.energygrid.enums.PlanStatus;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.ConsumerAccountRepository;
import com.cts.energygrid.repository.InstallmentPlanRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.InstallmentPlanService;

@Service
public class InstallmentPlanServiceImpl implements InstallmentPlanService {

    @Autowired
    private InstallmentPlanRepository installmentPlanRepository;

    @Autowired
    private ConsumerAccountRepository consumerAccountRepository;

    @Autowired
    private AuditLogService auditLogService;

    @Override
    public InstallmentPlanResponse createPlan(InstallmentPlanRequest req) {
        ConsumerAccount account = consumerAccountRepository.findById(req.getAccountId())
                .orElseThrow(() -> new ResourceNotFoundException("ConsumerAccount not found with id: " + req.getAccountId()));

        InstallmentPlan plan = new InstallmentPlan();
        plan.setAccount(account);
        plan.setTotalDue(req.getTotalDue());
        plan.setInstallments(req.getInstallments());
        plan.setStartDate(req.getStartDate());
        plan.setEndDate(req.getEndDate());
        plan.setStatus(PlanStatus.ACTIVE);

        InstallmentPlan saved = installmentPlanRepository.save(plan);
        auditLogService.log("CREATE", "InstallmentPlan", String.valueOf(saved.getPlanId()), account.getAccountId());
        return mapToResponse(saved);
    }

    @Override
    public List<InstallmentPlanResponse> getPlansByAccount(Long accountId) {
        return installmentPlanRepository.findByAccount_AccountId(accountId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public InstallmentPlanResponse updateStatus(Long id, PlanStatus status) {
        InstallmentPlan plan = installmentPlanRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("InstallmentPlan not found with id: " + id));
        plan.setStatus(status);
        InstallmentPlan saved = installmentPlanRepository.save(plan);
        auditLogService.log("UPDATE", "InstallmentPlan", String.valueOf(saved.getPlanId()), null);
        return mapToResponse(saved);
    }

    @Override
    public InstallmentPlanResponse getPlanById(Long id) {
        InstallmentPlan plan = installmentPlanRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Installment plan not found with id: " + id));
        return mapToResponse(plan);
    }

    @Override
    public List<InstallmentPlanResponse> getActivePlans() {
        return installmentPlanRepository.findByStatus(PlanStatus.ACTIVE).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public InstallmentPlanResponse markPlanCompleted(Long id) {
        InstallmentPlan plan = installmentPlanRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Installment plan not found with id: " + id));
        plan.setStatus(PlanStatus.COMPLETED);
        InstallmentPlan saved = installmentPlanRepository.save(plan);
        auditLogService.log("UPDATE", "InstallmentPlan", String.valueOf(saved.getPlanId()),
                saved.getAccount() != null ? saved.getAccount().getAccountId() : null);
        return mapToResponse(saved);
    }

    @Override
    public InstallmentPlanResponse markPlanDefaulted(Long id) {
        InstallmentPlan plan = installmentPlanRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Installment plan not found with id: " + id));
        plan.setStatus(PlanStatus.DEFAULTED);
        InstallmentPlan saved = installmentPlanRepository.save(plan);
        auditLogService.log("UPDATE", "InstallmentPlan", String.valueOf(saved.getPlanId()),
                saved.getAccount() != null ? saved.getAccount().getAccountId() : null);
        return mapToResponse(saved);
    }

    private InstallmentPlanResponse mapToResponse(InstallmentPlan plan) {
        return new InstallmentPlanResponse(
                plan.getPlanId(),
                plan.getAccount() != null ? plan.getAccount().getAccountId() : null,
                plan.getTotalDue(),
                plan.getInstallments(),
                plan.getStartDate(),
                plan.getEndDate(),
                plan.getStatus());
    }
}
