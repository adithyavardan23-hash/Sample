package com.cts.energygrid.service;

import java.util.List;

import com.cts.energygrid.dto.request.BillRequest;
import com.cts.energygrid.dto.response.BillResponse;
import com.cts.energygrid.enums.BillStatus;

public interface BillingService {

    BillResponse generateBill(BillRequest req);

    BillResponse getBillById(Long id);

    List<BillResponse> getBillsByAccount(Long accountId);

    BillResponse updateStatus(Long id, BillStatus status);

    List<BillResponse> getOverdueBills();

    BillResponse sendBill(Long id);

    BillResponse markAsPaid(Long id);

    BillResponse markAsOverdue(Long id);

    List<BillResponse> getBillsByStatus(BillStatus status);
}
