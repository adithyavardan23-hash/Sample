package com.cts.energygrid.dto.response;

import java.time.LocalDate;

import com.cts.energygrid.enums.DisputeStatus;

public class BillingDisputeResponse {

    private Long disputeId;
    private Long billId;
    private Long consumerId;
    private String reason;
    private LocalDate raisedDate;
    private DisputeStatus status;

    public BillingDisputeResponse() {
    }

    public BillingDisputeResponse(Long disputeId, Long billId, Long consumerId, String reason,
                                  LocalDate raisedDate, DisputeStatus status) {
        this.disputeId = disputeId;
        this.billId = billId;
        this.consumerId = consumerId;
        this.reason = reason;
        this.raisedDate = raisedDate;
        this.status = status;
    }

    public Long getDisputeId() {
        return disputeId;
    }

    public void setDisputeId(Long disputeId) {
        this.disputeId = disputeId;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public Long getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(Long consumerId) {
        this.consumerId = consumerId;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public LocalDate getRaisedDate() {
        return raisedDate;
    }

    public void setRaisedDate(LocalDate raisedDate) {
        this.raisedDate = raisedDate;
    }

    public DisputeStatus getStatus() {
        return status;
    }

    public void setStatus(DisputeStatus status) {
        this.status = status;
    }
}
