package com.cts.energygrid.dto.request;

import java.time.LocalDate;

import com.cts.energygrid.enums.RequestStatus;
import com.cts.energygrid.enums.RequestType;

public class ConnectionRequestRequest {

    private Long consumerId;
    private RequestType requestType;
    private LocalDate requestDate;
    private Long assignedTechId;
    private RequestStatus status;

    public ConnectionRequestRequest() {
    }

    public ConnectionRequestRequest(Long consumerId, RequestType requestType, LocalDate requestDate,
            Long assignedTechId, RequestStatus status) {
        this.consumerId = consumerId;
        this.requestType = requestType;
        this.requestDate = requestDate;
        this.assignedTechId = assignedTechId;
        this.status = status;
    }

    public Long getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(Long consumerId) {
        this.consumerId = consumerId;
    }

    public RequestType getRequestType() {
        return requestType;
    }

    public void setRequestType(RequestType requestType) {
        this.requestType = requestType;
    }

    public LocalDate getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(LocalDate requestDate) {
        this.requestDate = requestDate;
    }

    public Long getAssignedTechId() {
        return assignedTechId;
    }

    public void setAssignedTechId(Long assignedTechId) {
        this.assignedTechId = assignedTechId;
    }

    public RequestStatus getStatus() {
        return status;
    }

    public void setStatus(RequestStatus status) {
        this.status = status;
    }
}
