package com.cts.energygrid.service.impl;

import com.cts.energygrid.dto.request.OutageEventRequest;
import com.cts.energygrid.dto.response.OutageEventResponse;
import com.cts.energygrid.entity.OutageEvent;
import com.cts.energygrid.enums.OutageStatus;
import com.cts.energygrid.exception.BadRequestException;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.OutageEventRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.OutageEventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OutageEventServiceImpl implements OutageEventService {

    @Autowired
    private OutageEventRepository outageEventRepository;

    @Autowired
    private AuditLogService auditLogService;

    @Override
    public OutageEventResponse logOutage(OutageEventRequest req) {
        OutageEvent outage = new OutageEvent();
        outage.setZoneId(req.getZoneId());
        outage.setAffectedAccounts(req.getAffectedAccounts());
        outage.setCause(req.getCause());
        outage.setStartTime(req.getStartTime());
        outage.setEstimatedRestoration(req.getEstimatedRestoration());
        outage.setStatus(OutageStatus.ACTIVE);

        OutageEvent saved = outageEventRepository.save(outage);
        auditLogService.log("OUTAGE_LOGGED", "OutageEvent", String.valueOf(saved.getOutageId()), saved.getOutageId());
        return mapToResponse(saved);
    }

    @Override
    public OutageEventResponse getOutageById(Long id) {
        OutageEvent outage = outageEventRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("OutageEvent not found with id: " + id));
        return mapToResponse(outage);
    }

    @Override
    public List<OutageEventResponse> getActiveOutages() {
        return outageEventRepository.findByStatus(OutageStatus.ACTIVE).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public OutageEventResponse restoreOutage(Long id) {
        OutageEvent outage = outageEventRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("OutageEvent not found with id: " + id));
        if (outage.getStatus() == OutageStatus.RESTORED) {
            throw new BadRequestException("Outage is already restored");
        }
        outage.setStatus(OutageStatus.RESTORED);
        outage.setActualRestoration(LocalDateTime.now());
        OutageEvent saved = outageEventRepository.save(outage);
        auditLogService.log("OUTAGE_RESTORED", "OutageEvent", String.valueOf(id), id);
        return mapToResponse(saved);
    }

    @Override
    public OutageEventResponse updateStatus(Long id, OutageStatus status) {
        OutageEvent outage = outageEventRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("OutageEvent not found with id: " + id));
        outage.setStatus(status);
        OutageEvent saved = outageEventRepository.save(outage);
        auditLogService.log("UPDATE", "OutageEvent", String.valueOf(saved.getOutageId()), saved.getOutageId());
        return mapToResponse(saved);
    }

    @Override
    public List<OutageEventResponse> getOutagesByZone(String zoneId) {
        return outageEventRepository.findByZoneId(zoneId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public OutageEventResponse updateEstimatedRestoration(Long id, LocalDateTime time) {
        OutageEvent outage = outageEventRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Outage not found with id: " + id));
        outage.setEstimatedRestoration(time);
        OutageEvent saved = outageEventRepository.save(outage);
        auditLogService.log("UPDATE", "OutageEvent", String.valueOf(id), id);
        return mapToResponse(saved);
    }

    private OutageEventResponse mapToResponse(OutageEvent outage) {
        return new OutageEventResponse(
                outage.getOutageId(),
                outage.getZoneId(),
                outage.getAffectedAccounts(),
                outage.getCause(),
                outage.getStartTime(),
                outage.getEstimatedRestoration(),
                outage.getActualRestoration(),
                outage.getStatus()
        );
    }
}
