package com.cts.energygrid.service;

import com.cts.energygrid.dto.response.EnergyReportResponse;
import com.cts.energygrid.enums.ReportScope;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public interface EnergyReportService {

    EnergyReportResponse generateReport(ReportScope scope);

    List<EnergyReportResponse> getAllReports();

    EnergyReportResponse getReportById(Long id);

    List<EnergyReportResponse> getReportsByScope(ReportScope scope);

    List<EnergyReportResponse> getReportsForPeriod(LocalDateTime from, LocalDateTime to);

    // Aggregated dashboard summary (counts per scope, total reports, latest report time).
    Map<String, Object> getSummary();
}
