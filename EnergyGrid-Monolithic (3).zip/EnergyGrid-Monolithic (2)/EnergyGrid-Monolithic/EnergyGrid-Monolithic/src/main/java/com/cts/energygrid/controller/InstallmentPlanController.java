package com.cts.energygrid.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.energygrid.dto.request.InstallmentPlanRequest;
import com.cts.energygrid.dto.response.InstallmentPlanResponse;
import com.cts.energygrid.enums.PlanStatus;
import com.cts.energygrid.service.InstallmentPlanService;

@RestController
@RequestMapping("/api/installments")
public class InstallmentPlanController {

    @Autowired
    private InstallmentPlanService installmentPlanService;

    @PostMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<InstallmentPlanResponse> createPlan(@RequestBody InstallmentPlanRequest request) {
        return ResponseEntity.ok(installmentPlanService.createPlan(request));
    }

    @GetMapping("/account/{accountId}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','CONSUMER')")
    public ResponseEntity<List<InstallmentPlanResponse>> getPlansByAccount(@PathVariable Long accountId) {
        return ResponseEntity.ok(installmentPlanService.getPlansByAccount(accountId));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<InstallmentPlanResponse> updateStatus(@PathVariable Long id, @RequestParam PlanStatus status) {
        return ResponseEntity.ok(installmentPlanService.updateStatus(id, status));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','CONSUMER')")
    public ResponseEntity<InstallmentPlanResponse> getPlanById(@PathVariable Long id) {
        return ResponseEntity.ok(installmentPlanService.getPlanById(id));
    }

    @GetMapping("/active")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<List<InstallmentPlanResponse>> getActivePlans() {
        return ResponseEntity.ok(installmentPlanService.getActivePlans());
    }

    @PatchMapping("/{id}/complete")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<InstallmentPlanResponse> markPlanCompleted(@PathVariable Long id) {
        return ResponseEntity.ok(installmentPlanService.markPlanCompleted(id));
    }

    @PatchMapping("/{id}/default")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<InstallmentPlanResponse> markPlanDefaulted(@PathVariable Long id) {
        return ResponseEntity.ok(installmentPlanService.markPlanDefaulted(id));
    }
}
