package com.cts.energygrid.enums;

public enum ReportScope {
    ZONE("Zone"),
    CATEGORY("Category"),
    PERIOD("Period"),
    GRID("Grid");

    private final String displayName;

    ReportScope(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
