package com.cts.energygrid.controller;

import com.cts.energygrid.dto.request.TariffRequest;
import com.cts.energygrid.dto.response.TariffResponse;
import com.cts.energygrid.enums.ConsumerCategory;
import com.cts.energygrid.enums.TariffStatus;
import com.cts.energygrid.service.TariffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/tariffs")
public class TariffController {

    @Autowired
    private TariffService tariffService;

    @PostMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<TariffResponse> createTariff(@RequestBody TariffRequest req) {
        return ResponseEntity.ok(tariffService.createTariff(req));
    }

    @GetMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','GRID_OPS','COMPLIANCE','CONSUMER','FIELD_TECH')")
    public ResponseEntity<List<TariffResponse>> getAllTariffs() {
        return ResponseEntity.ok(tariffService.getAllTariffs());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','GRID_OPS','COMPLIANCE','CONSUMER','FIELD_TECH')")
    public ResponseEntity<TariffResponse> getTariffById(@PathVariable Long id) {
        return ResponseEntity.ok(tariffService.getTariffById(id));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<TariffResponse> updateStatus(@PathVariable Long id, @RequestParam TariffStatus status) {
        return ResponseEntity.ok(tariffService.updateStatus(id, status));
    }

    @GetMapping("/active/{category}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','GRID_OPS','COMPLIANCE','CONSUMER','FIELD_TECH')")
    public ResponseEntity<TariffResponse> getActiveTariffByCategory(@PathVariable ConsumerCategory category) {
        return ResponseEntity.ok(tariffService.getActiveTariffByCategory(category));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<TariffResponse> updateTariff(@PathVariable Long id, @RequestBody TariffRequest req) {
        return ResponseEntity.ok(tariffService.updateTariff(id, req));
    }

    @PatchMapping("/{id}/expire")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<TariffResponse> expireTariff(@PathVariable Long id) {
        return ResponseEntity.ok(tariffService.expireTariff(id));
    }
}
