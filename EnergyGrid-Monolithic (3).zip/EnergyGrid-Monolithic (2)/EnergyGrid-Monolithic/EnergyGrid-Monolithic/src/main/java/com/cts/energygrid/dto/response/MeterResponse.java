package com.cts.energygrid.dto.response;

import com.cts.energygrid.enums.MeterStatus;
import com.cts.energygrid.enums.MeterType;
import java.time.LocalDate;

public class MeterResponse {

    private Long meterId;
    private Long accountId;
    private String meterNumber;
    private MeterType type;
    private LocalDate installedDate;
    private MeterStatus status;

    public MeterResponse() {
    }

    public MeterResponse(Long meterId, Long accountId, String meterNumber, MeterType type, LocalDate installedDate, MeterStatus status) {
        this.meterId = meterId;
        this.accountId = accountId;
        this.meterNumber = meterNumber;
        this.type = type;
        this.installedDate = installedDate;
        this.status = status;
    }

    public Long getMeterId() {
        return meterId;
    }

    public void setMeterId(Long meterId) {
        this.meterId = meterId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public void setMeterNumber(String meterNumber) {
        this.meterNumber = meterNumber;
    }

    public MeterType getType() {
        return type;
    }

    public void setType(MeterType type) {
        this.type = type;
    }

    public LocalDate getInstalledDate() {
        return installedDate;
    }

    public void setInstalledDate(LocalDate installedDate) {
        this.installedDate = installedDate;
    }

    public MeterStatus getStatus() {
        return status;
    }

    public void setStatus(MeterStatus status) {
        this.status = status;
    }
}
