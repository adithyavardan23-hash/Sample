package com.cts.energygrid.service;

import java.util.List;

import com.cts.energygrid.dto.request.UserRequest;
import com.cts.energygrid.dto.response.UserResponse;
import com.cts.energygrid.enums.Role;

public interface UserService {

    UserResponse register(UserRequest request);

    UserResponse getUserById(Long id);

    List<UserResponse> getAllUsers();

    List<UserResponse> getUsersByRole(Role role);

    UserResponse updateUser(Long id, UserRequest request);

    void deactivateUser(Long id);
}
