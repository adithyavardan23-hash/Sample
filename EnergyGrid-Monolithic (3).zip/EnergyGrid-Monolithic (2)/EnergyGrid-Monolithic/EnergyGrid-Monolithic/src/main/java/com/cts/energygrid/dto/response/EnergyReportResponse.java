package com.cts.energygrid.dto.response;

import com.cts.energygrid.enums.ReportScope;
import java.time.LocalDateTime;

public class EnergyReportResponse {

    private Long reportId;
    private ReportScope scope;
    private String metrics;
    private LocalDateTime generatedDate;

    public EnergyReportResponse() {
    }

    public EnergyReportResponse(Long reportId, ReportScope scope, String metrics, LocalDateTime generatedDate) {
        this.reportId = reportId;
        this.scope = scope;
        this.metrics = metrics;
        this.generatedDate = generatedDate;
    }

    public Long getReportId() {
        return reportId;
    }

    public void setReportId(Long reportId) {
        this.reportId = reportId;
    }

    public ReportScope getScope() {
        return scope;
    }

    public void setScope(ReportScope scope) {
        this.scope = scope;
    }

    public String getMetrics() {
        return metrics;
    }

    public void setMetrics(String metrics) {
        this.metrics = metrics;
    }

    public LocalDateTime getGeneratedDate() {
        return generatedDate;
    }

    public void setGeneratedDate(LocalDateTime generatedDate) {
        this.generatedDate = generatedDate;
    }
}
