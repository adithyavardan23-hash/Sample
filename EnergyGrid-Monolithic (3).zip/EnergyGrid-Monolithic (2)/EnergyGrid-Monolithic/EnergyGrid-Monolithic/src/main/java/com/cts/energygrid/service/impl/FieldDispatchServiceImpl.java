package com.cts.energygrid.service.impl;

import com.cts.energygrid.dto.request.FieldDispatchRequest;
import com.cts.energygrid.dto.response.FieldDispatchResponse;
import com.cts.energygrid.entity.FieldDispatch;
import com.cts.energygrid.entity.OutageEvent;
import com.cts.energygrid.entity.User;
import com.cts.energygrid.enums.DispatchStatus;
import com.cts.energygrid.exception.BadRequestException;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.FieldDispatchRepository;
import com.cts.energygrid.repository.OutageEventRepository;
import com.cts.energygrid.repository.UserRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.FieldDispatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FieldDispatchServiceImpl implements FieldDispatchService {

    @Autowired
    private FieldDispatchRepository fieldDispatchRepository;

    @Autowired
    private OutageEventRepository outageEventRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuditLogService auditLogService;

    @Override
    public FieldDispatchResponse dispatchTechnician(FieldDispatchRequest req) {
        OutageEvent outage = outageEventRepository.findById(req.getOutageId())
                .orElseThrow(() -> new BadRequestException("Outage not found with id: " + req.getOutageId()));
        User technician = userRepository.findById(req.getTechnicianId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + req.getTechnicianId()));

        FieldDispatch dispatch = new FieldDispatch();
        dispatch.setOutage(outage);
        dispatch.setTechnician(technician);
        dispatch.setDispatchTime(req.getDispatchTime());
        dispatch.setArrivalTime(req.getArrivalTime());
        dispatch.setResolutionTime(req.getResolutionTime());
        dispatch.setStatus(DispatchStatus.DISPATCHED);

        FieldDispatch saved = fieldDispatchRepository.save(dispatch);
        auditLogService.log("CREATE", "FieldDispatch", String.valueOf(saved.getDispatchId()), saved.getDispatchId());
        return mapToResponse(saved);
    }

    @Override
    public List<FieldDispatchResponse> getDispatchesByOutage(Long outageId) {
        return fieldDispatchRepository.findByOutage_OutageId(outageId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public FieldDispatchResponse updateStatus(Long id, DispatchStatus status) {
        FieldDispatch dispatch = fieldDispatchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("FieldDispatch not found with id: " + id));
        dispatch.setStatus(status);
        FieldDispatch saved = fieldDispatchRepository.save(dispatch);
        auditLogService.log("UPDATE", "FieldDispatch", String.valueOf(saved.getDispatchId()), saved.getDispatchId());
        return mapToResponse(saved);
    }

    @Override
    public FieldDispatchResponse getDispatchById(Long id) {
        FieldDispatch dispatch = fieldDispatchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Dispatch not found with id: " + id));
        return mapToResponse(dispatch);
    }

    @Override
    public List<FieldDispatchResponse> getDispatchesByTechnician(Long techId) {
        return fieldDispatchRepository.findByTechnician_UserId(techId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public FieldDispatchResponse markOnSite(Long id) {
        FieldDispatch dispatch = fieldDispatchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Dispatch not found with id: " + id));
        dispatch.setStatus(DispatchStatus.ON_SITE);
        dispatch.setArrivalTime(LocalDateTime.now());
        FieldDispatch saved = fieldDispatchRepository.save(dispatch);
        auditLogService.log("UPDATE", "FieldDispatch", String.valueOf(id), id);
        return mapToResponse(saved);
    }

    @Override
    public FieldDispatchResponse markResolved(Long id) {
        FieldDispatch dispatch = fieldDispatchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Dispatch not found with id: " + id));
        dispatch.setStatus(DispatchStatus.RESOLVED);
        dispatch.setResolutionTime(LocalDateTime.now());
        FieldDispatch saved = fieldDispatchRepository.save(dispatch);
        auditLogService.log("UPDATE", "FieldDispatch", String.valueOf(id), id);
        return mapToResponse(saved);
    }

    private FieldDispatchResponse mapToResponse(FieldDispatch dispatch) {
        Long outageId = dispatch.getOutage() != null ? dispatch.getOutage().getOutageId() : null;
        Long technicianId = dispatch.getTechnician() != null ? dispatch.getTechnician().getUserId() : null;
        return new FieldDispatchResponse(
                dispatch.getDispatchId(),
                outageId,
                technicianId,
                dispatch.getDispatchTime(),
                dispatch.getArrivalTime(),
                dispatch.getResolutionTime(),
                dispatch.getStatus()
        );
    }
}
