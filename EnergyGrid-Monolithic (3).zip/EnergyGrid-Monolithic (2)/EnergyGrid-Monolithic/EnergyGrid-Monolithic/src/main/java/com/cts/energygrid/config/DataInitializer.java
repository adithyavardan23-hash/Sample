package com.cts.energygrid.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.cts.energygrid.entity.User;
import com.cts.energygrid.enums.Role;
import com.cts.energygrid.enums.UserStatus;
import com.cts.energygrid.repository.UserRepository;

/*
 * Bootstraps a default ADMIN account on startup.
 *
 * Because user creation (/api/users/register) is restricted to ADMIN and passwords
 * are BCrypt-hashed, there must be at least one admin to log in with. This seeder
 * creates that admin once (only if it does not already exist), so the system is
 * usable immediately after a fresh start.
 *
 *   email    : admin@energygrid.com
 *   password : admin123   (hashed before storage)
 */
@Configuration
public class DataInitializer {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(DataInitializer.class);

    private static final String DEFAULT_ADMIN_EMAIL = "admin@energygrid.com";
    private static final String DEFAULT_ADMIN_PASSWORD = "admin123";

    @Bean
    public CommandLineRunner seedDefaultAdmin(UserRepository userRepository, BCryptPasswordEncoder passwordEncoder) {
        return args -> {
            if (userRepository.existsByEmail(DEFAULT_ADMIN_EMAIL)) {
                log.info("Default admin already present; skipping seed.");
                return;
            }
            User admin = new User();
            admin.setName("System Administrator");
            admin.setRole(Role.ADMIN);
            admin.setEmail(DEFAULT_ADMIN_EMAIL);
            admin.setPassword(passwordEncoder.encode(DEFAULT_ADMIN_PASSWORD));
            admin.setPhone("0000000000");
            admin.setZoneId("ZONE-0");
            admin.setStatus(UserStatus.ACTIVE);
            userRepository.save(admin);
            log.info("Seeded default ADMIN user: {} (change the password after first login).", DEFAULT_ADMIN_EMAIL);
        };
    }
}
