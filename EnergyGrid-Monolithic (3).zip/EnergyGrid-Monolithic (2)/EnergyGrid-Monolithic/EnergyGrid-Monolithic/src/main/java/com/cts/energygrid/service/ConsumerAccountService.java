package com.cts.energygrid.service;

import java.util.List;

import com.cts.energygrid.dto.request.ConsumerAccountRequest;
import com.cts.energygrid.dto.response.ConsumerAccountResponse;
import com.cts.energygrid.enums.AccountStatus;

public interface ConsumerAccountService {

    ConsumerAccountResponse createAccount(ConsumerAccountRequest req);

    ConsumerAccountResponse getAccountById(Long id);

    List<ConsumerAccountResponse> getAllAccounts();

    ConsumerAccountResponse updateStatus(Long id, AccountStatus status);

    ConsumerAccountResponse getAccountByConsumerId(Long consumerId);

    List<ConsumerAccountResponse> getAccountsByZone(String zoneId);

    ConsumerAccountResponse updateAccount(Long id, ConsumerAccountRequest req);

    ConsumerAccountResponse suspendAccount(Long id);

    ConsumerAccountResponse disconnectAccount(Long id);

    ConsumerAccountResponse reactivateAccount(Long id);
}
