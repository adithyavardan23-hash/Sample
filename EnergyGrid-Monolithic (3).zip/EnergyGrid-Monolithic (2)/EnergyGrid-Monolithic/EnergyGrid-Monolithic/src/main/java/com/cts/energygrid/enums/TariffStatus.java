package com.cts.energygrid.enums;

public enum TariffStatus {
    ACTIVE("Active"),
    EXPIRED("Expired");

    private final String displayName;

    TariffStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
