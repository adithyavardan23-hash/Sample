package com.cts.energygrid.service;

import java.time.LocalDateTime;
import java.util.List;

import com.cts.energygrid.dto.response.AuditLogResponse;

public interface AuditLogService {

    /*
     * SHARED METHOD — DO NOT CHANGE THE SIGNATURE.
     * Called by other services (e.g. UserServiceImpl) to record audit entries.
     */
    void log(String action, String entityType, String entityId, Long performedBy);

    // PROBLEM 5 FIX: now returns DTOs instead of entities.
    List<AuditLogResponse> getAllLogs();

    // PROBLEM 6 FIX: new filter queries.
    List<AuditLogResponse> getLogsByUserId(Long userId);

    List<AuditLogResponse> getLogsByAction(String action);

    List<AuditLogResponse> getLogsByDateRange(LocalDateTime from, LocalDateTime to);
}
