package com.cts.energygrid.service;

import com.cts.energygrid.dto.request.MeterReadingRequest;
import com.cts.energygrid.dto.response.MeterReadingResponse;
import java.time.LocalDate;
import java.util.List;

public interface MeterReadingService {

    MeterReadingResponse addReading(MeterReadingRequest req);

    List<MeterReadingResponse> getReadingsByMeter(Long meterId);

    MeterReadingResponse getLatestReading(Long meterId);

    List<MeterReadingResponse> getReadingsForPeriod(Long meterId, LocalDate start, LocalDate end);

    MeterReadingResponse validateReading(Long id);

    MeterReadingResponse disputeReading(Long id);
}
