package com.cts.energygrid.controller;

import com.cts.energygrid.dto.request.OutageEventRequest;
import com.cts.energygrid.dto.response.OutageEventResponse;
import com.cts.energygrid.enums.OutageStatus;
import com.cts.energygrid.service.OutageEventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/outages")
public class OutageEventController {

    @Autowired
    private OutageEventService outageEventService;

    @PostMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS')")
    public ResponseEntity<OutageEventResponse> logOutage(@RequestBody OutageEventRequest req) {
        return ResponseEntity.ok(outageEventService.logOutage(req));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS','FIELD_TECH','CONSUMER')")
    public ResponseEntity<OutageEventResponse> getOutageById(@PathVariable Long id) {
        return ResponseEntity.ok(outageEventService.getOutageById(id));
    }

    @GetMapping("/active")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS','FIELD_TECH','CONSUMER','BILLING','COMPLIANCE')")
    public ResponseEntity<List<OutageEventResponse>> getActiveOutages() {
        return ResponseEntity.ok(outageEventService.getActiveOutages());
    }

    @PatchMapping("/{id}/restore")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS')")
    public ResponseEntity<OutageEventResponse> restoreOutage(@PathVariable Long id) {
        return ResponseEntity.ok(outageEventService.restoreOutage(id));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS')")
    public ResponseEntity<OutageEventResponse> updateStatus(@PathVariable Long id,
                                                            @RequestParam OutageStatus status) {
        return ResponseEntity.ok(outageEventService.updateStatus(id, status));
    }

    @GetMapping("/zone/{zoneId}")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS','FIELD_TECH')")
    public ResponseEntity<List<OutageEventResponse>> getOutagesByZone(@PathVariable String zoneId) {
        return ResponseEntity.ok(outageEventService.getOutagesByZone(zoneId));
    }

    @PatchMapping("/{id}/eta")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS')")
    public ResponseEntity<OutageEventResponse> updateEstimatedRestoration(@PathVariable Long id,
                                                                          @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime time) {
        return ResponseEntity.ok(outageEventService.updateEstimatedRestoration(id, time));
    }
}
