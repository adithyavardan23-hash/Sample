package com.cts.energygrid.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.energygrid.dto.response.AuthResponse;
import com.cts.energygrid.entity.User;
import com.cts.energygrid.exception.UnauthorizedException;
import com.cts.energygrid.repository.UserRepository;
import com.cts.energygrid.service.AuthService;
import com.cts.energygrid.util.JwtUtil;

@Service
public class AuthServiceImpl implements AuthService {

    // Project uses plain SLF4J (no Lombok), matching LoggingAspect's style.
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(AuthServiceImpl.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    // Passwords are BCrypt-hashed at registration; verify against the hash here.
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Override
    public AuthResponse login(String email, String password) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UnauthorizedException("Invalid credentials"));

        // BCrypt verification: compare the raw password against the stored hash.
        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new UnauthorizedException("Invalid credentials");
        }

        String token = jwtUtil.generateToken(user.getEmail(), user.getRole().name());
        log.info("Login successful for userId={} role={}", user.getUserId(), user.getRole());

        // PROBLEM 1 FIX: return token + role + userId so the frontend can
        // redirect by role and use userId for follow-up API calls.
        return new AuthResponse(token, user.getRole().name(), user.getUserId());
    }
}
