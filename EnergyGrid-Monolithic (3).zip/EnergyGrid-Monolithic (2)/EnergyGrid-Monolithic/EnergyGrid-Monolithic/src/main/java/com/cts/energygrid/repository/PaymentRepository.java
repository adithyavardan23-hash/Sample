package com.cts.energygrid.repository;

import com.cts.energygrid.entity.Payment;
import com.cts.energygrid.enums.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PaymentRepository extends JpaRepository<Payment, Long> {

    List<Payment> findByAccount_AccountId(Long accountId);

    List<Payment> findByBill_BillId(Long billId);

    List<Payment> findByStatus(PaymentStatus status);
}
