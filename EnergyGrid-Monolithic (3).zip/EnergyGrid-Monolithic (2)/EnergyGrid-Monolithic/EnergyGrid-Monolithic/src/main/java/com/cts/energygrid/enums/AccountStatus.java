package com.cts.energygrid.enums;

public enum AccountStatus {
    ACTIVE("Active"),
    SUSPENDED("Suspended"),
    DISCONNECTED("Disconnected");

    private final String displayName;

    AccountStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
