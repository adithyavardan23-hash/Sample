package com.cts.energygrid.enums;

public enum ReadingStatus {
    VALIDATED("Validated"),
    ESTIMATED("Estimated"),
    DISPUTED("Disputed");

    private final String displayName;

    ReadingStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
