package com.cts.energygrid.controller;

import com.cts.energygrid.dto.request.MeterReadingRequest;
import com.cts.energygrid.dto.response.MeterReadingResponse;
import com.cts.energygrid.service.MeterReadingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/readings")
public class MeterReadingController {

    @Autowired
    private MeterReadingService meterReadingService;

    @PostMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH')")
    public ResponseEntity<MeterReadingResponse> addReading(@RequestBody MeterReadingRequest req) {
        return ResponseEntity.ok(meterReadingService.addReading(req));
    }

    @GetMapping("/meter/{meterId}")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH','BILLING','GRID_OPS','CONSUMER')")
    public ResponseEntity<List<MeterReadingResponse>> getReadingsByMeter(@PathVariable Long meterId) {
        return ResponseEntity.ok(meterReadingService.getReadingsByMeter(meterId));
    }

    @GetMapping("/meter/{meterId}/latest")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH','BILLING','GRID_OPS','CONSUMER')")
    public ResponseEntity<MeterReadingResponse> getLatestReading(@PathVariable Long meterId) {
        return ResponseEntity.ok(meterReadingService.getLatestReading(meterId));
    }

    @GetMapping("/meter/{meterId}/period")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH','BILLING','GRID_OPS','CONSUMER')")
    public ResponseEntity<List<MeterReadingResponse>> getReadingsForPeriod(
            @PathVariable Long meterId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate start,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate end) {
        return ResponseEntity.ok(meterReadingService.getReadingsForPeriod(meterId, start, end));
    }

    @PatchMapping("/{id}/validate")
    @PreAuthorize("hasAnyRole('ADMIN','FIELD_TECH','BILLING')")
    public ResponseEntity<MeterReadingResponse> validateReading(@PathVariable Long id) {
        return ResponseEntity.ok(meterReadingService.validateReading(id));
    }

    @PatchMapping("/{id}/dispute")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','CONSUMER')")
    public ResponseEntity<MeterReadingResponse> disputeReading(@PathVariable Long id) {
        return ResponseEntity.ok(meterReadingService.disputeReading(id));
    }
}
