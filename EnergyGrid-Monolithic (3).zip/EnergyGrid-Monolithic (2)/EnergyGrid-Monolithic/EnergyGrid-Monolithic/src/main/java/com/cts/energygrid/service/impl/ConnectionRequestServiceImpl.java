package com.cts.energygrid.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.energygrid.dto.request.ConnectionRequestRequest;
import com.cts.energygrid.dto.response.ConnectionRequestResponse;
import com.cts.energygrid.entity.ConnectionRequest;
import com.cts.energygrid.entity.User;
import com.cts.energygrid.enums.RequestStatus;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.ConnectionRequestRepository;
import com.cts.energygrid.repository.UserRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.ConnectionRequestService;

@Service
public class ConnectionRequestServiceImpl implements ConnectionRequestService {

    @Autowired
    private ConnectionRequestRepository connectionRequestRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuditLogService auditLogService;

    @Override
    public ConnectionRequestResponse submitRequest(ConnectionRequestRequest req) {
        User consumer = userRepository.findById(req.getConsumerId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + req.getConsumerId()));

        ConnectionRequest request = new ConnectionRequest();
        request.setConsumer(consumer);
        request.setRequestType(req.getRequestType());
        request.setRequestDate(req.getRequestDate());
        request.setAssignedTechId(req.getAssignedTechId());
        request.setStatus(req.getStatus());

        ConnectionRequest saved = connectionRequestRepository.save(request);
        auditLogService.log("CREATE", "ConnectionRequest", String.valueOf(saved.getRequestId()), consumer.getUserId());
        return toResponse(saved);
    }

    @Override
    public List<ConnectionRequestResponse> getAllRequests() {
        return connectionRequestRepository.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public ConnectionRequestResponse assignTechnician(Long requestId, Long techId) {
        ConnectionRequest request = connectionRequestRepository.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("ConnectionRequest not found with id: " + requestId));
        request.setAssignedTechId(techId);
        request.setStatus(RequestStatus.SCHEDULED);
        ConnectionRequest saved = connectionRequestRepository.save(request);
        auditLogService.log("UPDATE", "ConnectionRequest", String.valueOf(requestId), techId);
        return toResponse(saved);
    }

    @Override
    public ConnectionRequestResponse updateStatus(Long id, RequestStatus status) {
        ConnectionRequest request = connectionRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ConnectionRequest not found with id: " + id));
        request.setStatus(status);
        ConnectionRequest saved = connectionRequestRepository.save(request);
        auditLogService.log("UPDATE", "ConnectionRequest", String.valueOf(id), id);
        return toResponse(saved);
    }

    @Override
    public ConnectionRequestResponse getRequestById(Long id) {
        ConnectionRequest request = connectionRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Connection request not found with id: " + id));
        return toResponse(request);
    }

    @Override
    public List<ConnectionRequestResponse> getRequestsByConsumer(Long consumerId) {
        return connectionRequestRepository.findByConsumer_UserId(consumerId).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ConnectionRequestResponse> getPendingRequests() {
        return connectionRequestRepository.findByStatus(RequestStatus.PENDING).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    private ConnectionRequestResponse toResponse(ConnectionRequest request) {
        ConnectionRequestResponse response = new ConnectionRequestResponse();
        response.setRequestId(request.getRequestId());
        response.setConsumerId(request.getConsumer() != null ? request.getConsumer().getUserId() : null);
        response.setRequestType(request.getRequestType());
        response.setRequestDate(request.getRequestDate());
        response.setAssignedTechId(request.getAssignedTechId());
        response.setStatus(request.getStatus());
        return response;
    }
}
