package com.cts.energygrid.dto.response;

import com.cts.energygrid.enums.DispatchStatus;
import java.time.LocalDateTime;

public class FieldDispatchResponse {

    private Long dispatchId;
    private Long outageId;
    private Long technicianId;
    private LocalDateTime dispatchTime;
    private LocalDateTime arrivalTime;
    private LocalDateTime resolutionTime;
    private DispatchStatus status;

    public FieldDispatchResponse() {
    }

    public FieldDispatchResponse(Long dispatchId, Long outageId, Long technicianId, LocalDateTime dispatchTime,
                                 LocalDateTime arrivalTime, LocalDateTime resolutionTime, DispatchStatus status) {
        this.dispatchId = dispatchId;
        this.outageId = outageId;
        this.technicianId = technicianId;
        this.dispatchTime = dispatchTime;
        this.arrivalTime = arrivalTime;
        this.resolutionTime = resolutionTime;
        this.status = status;
    }

    public Long getDispatchId() {
        return dispatchId;
    }

    public void setDispatchId(Long dispatchId) {
        this.dispatchId = dispatchId;
    }

    public Long getOutageId() {
        return outageId;
    }

    public void setOutageId(Long outageId) {
        this.outageId = outageId;
    }

    public Long getTechnicianId() {
        return technicianId;
    }

    public void setTechnicianId(Long technicianId) {
        this.technicianId = technicianId;
    }

    public LocalDateTime getDispatchTime() {
        return dispatchTime;
    }

    public void setDispatchTime(LocalDateTime dispatchTime) {
        this.dispatchTime = dispatchTime;
    }

    public LocalDateTime getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(LocalDateTime arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public LocalDateTime getResolutionTime() {
        return resolutionTime;
    }

    public void setResolutionTime(LocalDateTime resolutionTime) {
        this.resolutionTime = resolutionTime;
    }

    public DispatchStatus getStatus() {
        return status;
    }

    public void setStatus(DispatchStatus status) {
        this.status = status;
    }
}
