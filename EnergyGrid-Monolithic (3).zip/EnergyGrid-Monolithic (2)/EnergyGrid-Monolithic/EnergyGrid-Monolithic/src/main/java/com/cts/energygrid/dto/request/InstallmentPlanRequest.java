package com.cts.energygrid.dto.request;

import java.time.LocalDate;

public class InstallmentPlanRequest {

    private Long accountId;
    private Double totalDue;
    private Integer installments;
    private LocalDate startDate;
    private LocalDate endDate;

    public InstallmentPlanRequest() {
    }

    public InstallmentPlanRequest(Long accountId, Double totalDue, Integer installments,
                                  LocalDate startDate, LocalDate endDate) {
        this.accountId = accountId;
        this.totalDue = totalDue;
        this.installments = installments;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Double getTotalDue() {
        return totalDue;
    }

    public void setTotalDue(Double totalDue) {
        this.totalDue = totalDue;
    }

    public Integer getInstallments() {
        return installments;
    }

    public void setInstallments(Integer installments) {
        this.installments = installments;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }
}
