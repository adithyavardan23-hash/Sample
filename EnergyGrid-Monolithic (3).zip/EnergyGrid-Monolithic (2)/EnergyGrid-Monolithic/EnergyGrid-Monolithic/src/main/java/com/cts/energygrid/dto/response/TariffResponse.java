package com.cts.energygrid.dto.response;

import com.cts.energygrid.enums.ConsumerCategory;
import com.cts.energygrid.enums.TariffStatus;
import java.time.LocalDate;

public class TariffResponse {

    private Long tariffId;
    private String name;
    private ConsumerCategory consumerCategory;
    private String slabRates;
    private Double fixedCharges;
    private Double taxRates;
    private LocalDate effectiveDate;
    private TariffStatus status;

    public TariffResponse() {
    }

    public TariffResponse(Long tariffId, String name, ConsumerCategory consumerCategory, String slabRates, Double fixedCharges, Double taxRates, LocalDate effectiveDate, TariffStatus status) {
        this.tariffId = tariffId;
        this.name = name;
        this.consumerCategory = consumerCategory;
        this.slabRates = slabRates;
        this.fixedCharges = fixedCharges;
        this.taxRates = taxRates;
        this.effectiveDate = effectiveDate;
        this.status = status;
    }

    public Long getTariffId() {
        return tariffId;
    }

    public void setTariffId(Long tariffId) {
        this.tariffId = tariffId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ConsumerCategory getConsumerCategory() {
        return consumerCategory;
    }

    public void setConsumerCategory(ConsumerCategory consumerCategory) {
        this.consumerCategory = consumerCategory;
    }

    public String getSlabRates() {
        return slabRates;
    }

    public void setSlabRates(String slabRates) {
        this.slabRates = slabRates;
    }

    public Double getFixedCharges() {
        return fixedCharges;
    }

    public void setFixedCharges(Double fixedCharges) {
        this.fixedCharges = fixedCharges;
    }

    public Double getTaxRates() {
        return taxRates;
    }

    public void setTaxRates(Double taxRates) {
        this.taxRates = taxRates;
    }

    public LocalDate getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public TariffStatus getStatus() {
        return status;
    }

    public void setStatus(TariffStatus status) {
        this.status = status;
    }
}
