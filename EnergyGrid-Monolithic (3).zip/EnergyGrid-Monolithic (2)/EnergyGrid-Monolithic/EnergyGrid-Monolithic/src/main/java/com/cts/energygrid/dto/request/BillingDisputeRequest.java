package com.cts.energygrid.dto.request;

import java.time.LocalDate;

public class BillingDisputeRequest {

    private Long billId;
    private Long consumerId;
    private String reason;
    private LocalDate raisedDate;

    public BillingDisputeRequest() {
    }

    public BillingDisputeRequest(Long billId, Long consumerId, String reason, LocalDate raisedDate) {
        this.billId = billId;
        this.consumerId = consumerId;
        this.reason = reason;
        this.raisedDate = raisedDate;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public Long getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(Long consumerId) {
        this.consumerId = consumerId;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public LocalDate getRaisedDate() {
        return raisedDate;
    }

    public void setRaisedDate(LocalDate raisedDate) {
        this.raisedDate = raisedDate;
    }
}
