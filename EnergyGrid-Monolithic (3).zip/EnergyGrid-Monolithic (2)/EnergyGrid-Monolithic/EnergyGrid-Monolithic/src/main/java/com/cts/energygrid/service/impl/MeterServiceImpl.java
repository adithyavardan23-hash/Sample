package com.cts.energygrid.service.impl;

import com.cts.energygrid.dto.request.MeterRequest;
import com.cts.energygrid.dto.response.MeterResponse;
import com.cts.energygrid.entity.ConsumerAccount;
import com.cts.energygrid.entity.Meter;
import com.cts.energygrid.enums.MeterStatus;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.ConsumerAccountRepository;
import com.cts.energygrid.repository.MeterRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.MeterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MeterServiceImpl implements MeterService {

    @Autowired
    private MeterRepository meterRepository;

    @Autowired
    private ConsumerAccountRepository consumerAccountRepository;

    @Autowired
    private AuditLogService auditLogService;

    @Override
    public MeterResponse installMeter(MeterRequest req) {
        ConsumerAccount account = consumerAccountRepository.findById(req.getAccountId())
                .orElseThrow(() -> new ResourceNotFoundException("ConsumerAccount not found with id: " + req.getAccountId()));

        Meter meter = new Meter();
        meter.setAccount(account);
        meter.setMeterNumber(req.getMeterNumber());
        meter.setType(req.getType());
        meter.setInstalledDate(req.getInstalledDate());
        meter.setStatus(req.getStatus());

        Meter saved = meterRepository.save(meter);
        auditLogService.log("CREATE", "Meter", String.valueOf(saved.getMeterId()), saved.getMeterId());
        return mapToResponse(saved);
    }

    @Override
    public MeterResponse getMeterById(Long id) {
        Meter meter = meterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Meter not found with id: " + id));
        return mapToResponse(meter);
    }

    @Override
    public List<MeterResponse> getMetersByAccount(Long accountId) {
        return meterRepository.findByAccount_AccountId(accountId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public MeterResponse updateStatus(Long id, MeterStatus status) {
        Meter meter = meterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Meter not found with id: " + id));
        meter.setStatus(status);
        Meter saved = meterRepository.save(meter);
        auditLogService.log("UPDATE", "Meter", String.valueOf(saved.getMeterId()), saved.getMeterId());
        return mapToResponse(saved);
    }

    @Override
    public List<MeterResponse> getFaultyMeters() {
        return meterRepository.findByStatus(MeterStatus.FAULTY).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public MeterResponse replaceMeter(Long oldMeterId, MeterRequest req) {
        Meter oldMeter = meterRepository.findById(oldMeterId)
                .orElseThrow(() -> new ResourceNotFoundException("Meter not found with id: " + oldMeterId));
        oldMeter.setStatus(MeterStatus.REPLACED);
        meterRepository.save(oldMeter);

        ConsumerAccount account = consumerAccountRepository.findById(req.getAccountId())
                .orElseThrow(() -> new ResourceNotFoundException("ConsumerAccount not found with id: " + req.getAccountId()));

        Meter newMeter = new Meter();
        newMeter.setAccount(account);
        newMeter.setMeterNumber(req.getMeterNumber());
        newMeter.setType(req.getType());
        newMeter.setInstalledDate(req.getInstalledDate());
        newMeter.setStatus(MeterStatus.ACTIVE);

        Meter saved = meterRepository.save(newMeter);
        auditLogService.log("UPDATE", "Meter", String.valueOf(saved.getMeterId()), saved.getMeterId());
        return mapToResponse(saved);
    }

    private MeterResponse mapToResponse(Meter meter) {
        Long accountId = meter.getAccount() != null ? meter.getAccount().getAccountId() : null;
        return new MeterResponse(
                meter.getMeterId(),
                accountId,
                meter.getMeterNumber(),
                meter.getType(),
                meter.getInstalledDate(),
                meter.getStatus()
        );
    }
}
