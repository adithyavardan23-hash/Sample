package com.cts.energygrid.dto.request;

import java.time.LocalDateTime;

public class FieldDispatchRequest {

    private Long outageId;
    private Long technicianId;
    private LocalDateTime dispatchTime;
    private LocalDateTime arrivalTime;
    private LocalDateTime resolutionTime;

    public FieldDispatchRequest() {
    }

    public FieldDispatchRequest(Long outageId, Long technicianId, LocalDateTime dispatchTime,
                                LocalDateTime arrivalTime, LocalDateTime resolutionTime) {
        this.outageId = outageId;
        this.technicianId = technicianId;
        this.dispatchTime = dispatchTime;
        this.arrivalTime = arrivalTime;
        this.resolutionTime = resolutionTime;
    }

    public Long getOutageId() {
        return outageId;
    }

    public void setOutageId(Long outageId) {
        this.outageId = outageId;
    }

    public Long getTechnicianId() {
        return technicianId;
    }

    public void setTechnicianId(Long technicianId) {
        this.technicianId = technicianId;
    }

    public LocalDateTime getDispatchTime() {
        return dispatchTime;
    }

    public void setDispatchTime(LocalDateTime dispatchTime) {
        this.dispatchTime = dispatchTime;
    }

    public LocalDateTime getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(LocalDateTime arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public LocalDateTime getResolutionTime() {
        return resolutionTime;
    }

    public void setResolutionTime(LocalDateTime resolutionTime) {
        this.resolutionTime = resolutionTime;
    }
}
