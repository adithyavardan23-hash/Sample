package com.cts.energygrid.dto.response;

import com.cts.energygrid.enums.OutageCause;
import com.cts.energygrid.enums.OutageStatus;
import java.time.LocalDateTime;

public class OutageEventResponse {

    private Long outageId;
    private String zoneId;
    private Integer affectedAccounts;
    private OutageCause cause;
    private LocalDateTime startTime;
    private LocalDateTime estimatedRestoration;
    private LocalDateTime actualRestoration;
    private OutageStatus status;

    public OutageEventResponse() {
    }

    public OutageEventResponse(Long outageId, String zoneId, Integer affectedAccounts, OutageCause cause,
                               LocalDateTime startTime, LocalDateTime estimatedRestoration,
                               LocalDateTime actualRestoration, OutageStatus status) {
        this.outageId = outageId;
        this.zoneId = zoneId;
        this.affectedAccounts = affectedAccounts;
        this.cause = cause;
        this.startTime = startTime;
        this.estimatedRestoration = estimatedRestoration;
        this.actualRestoration = actualRestoration;
        this.status = status;
    }

    public Long getOutageId() {
        return outageId;
    }

    public void setOutageId(Long outageId) {
        this.outageId = outageId;
    }

    public String getZoneId() {
        return zoneId;
    }

    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }

    public Integer getAffectedAccounts() {
        return affectedAccounts;
    }

    public void setAffectedAccounts(Integer affectedAccounts) {
        this.affectedAccounts = affectedAccounts;
    }

    public OutageCause getCause() {
        return cause;
    }

    public void setCause(OutageCause cause) {
        this.cause = cause;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEstimatedRestoration() {
        return estimatedRestoration;
    }

    public void setEstimatedRestoration(LocalDateTime estimatedRestoration) {
        this.estimatedRestoration = estimatedRestoration;
    }

    public LocalDateTime getActualRestoration() {
        return actualRestoration;
    }

    public void setActualRestoration(LocalDateTime actualRestoration) {
        this.actualRestoration = actualRestoration;
    }

    public OutageStatus getStatus() {
        return status;
    }

    public void setStatus(OutageStatus status) {
        this.status = status;
    }
}
