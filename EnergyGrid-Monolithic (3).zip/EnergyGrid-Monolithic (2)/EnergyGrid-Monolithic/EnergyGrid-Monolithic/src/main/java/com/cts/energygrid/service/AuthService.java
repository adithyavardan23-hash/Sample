package com.cts.energygrid.service;

import com.cts.energygrid.dto.response.AuthResponse;

public interface AuthService {

    /*
     * PROBLEM 1 FIX:
     * login() now returns a full AuthResponse (token + role + userId)
     * instead of a bare token String, so the frontend gets everything
     * it needs in a single response.
     */
    AuthResponse login(String email, String password);
}
