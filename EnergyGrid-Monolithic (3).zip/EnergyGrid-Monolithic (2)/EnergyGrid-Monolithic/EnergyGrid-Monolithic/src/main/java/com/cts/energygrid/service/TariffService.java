package com.cts.energygrid.service;

import com.cts.energygrid.dto.request.TariffRequest;
import com.cts.energygrid.dto.response.TariffResponse;
import com.cts.energygrid.enums.ConsumerCategory;
import com.cts.energygrid.enums.TariffStatus;
import java.util.List;

public interface TariffService {

    TariffResponse createTariff(TariffRequest req);

    TariffResponse getTariffById(Long id);

    List<TariffResponse> getAllTariffs();

    TariffResponse updateStatus(Long id, TariffStatus status);

    TariffResponse getActiveTariffByCategory(ConsumerCategory category);

    TariffResponse updateTariff(Long id, TariffRequest req);

    TariffResponse expireTariff(Long id);
}
