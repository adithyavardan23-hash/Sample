package com.cts.energygrid.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.energygrid.dto.request.BillingDisputeRequest;
import com.cts.energygrid.dto.response.BillingDisputeResponse;
import com.cts.energygrid.entity.Bill;
import com.cts.energygrid.entity.BillingDispute;
import com.cts.energygrid.entity.User;
import com.cts.energygrid.enums.DisputeStatus;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.BillRepository;
import com.cts.energygrid.repository.BillingDisputeRepository;
import com.cts.energygrid.repository.UserRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.BillingDisputeService;

@Service
public class BillingDisputeServiceImpl implements BillingDisputeService {

    @Autowired
    private BillingDisputeRepository billingDisputeRepository;

    @Autowired
    private BillRepository billRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuditLogService auditLogService;

    @Override
    public BillingDisputeResponse raiseDispute(BillingDisputeRequest req) {
        Bill bill = billRepository.findById(req.getBillId())
                .orElseThrow(() -> new ResourceNotFoundException("Bill not found with id: " + req.getBillId()));
        User consumer = userRepository.findById(req.getConsumerId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + req.getConsumerId()));

        BillingDispute dispute = new BillingDispute();
        dispute.setBill(bill);
        dispute.setConsumer(consumer);
        dispute.setReason(req.getReason());
        dispute.setRaisedDate(req.getRaisedDate());
        dispute.setStatus(DisputeStatus.OPEN);

        BillingDispute saved = billingDisputeRepository.save(dispute);
        auditLogService.log("CREATE", "BillingDispute", String.valueOf(saved.getDisputeId()), req.getConsumerId());
        return mapToResponse(saved);
    }

    @Override
    public List<BillingDisputeResponse> getAllDisputes() {
        return billingDisputeRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public BillingDisputeResponse updateStatus(Long id, DisputeStatus status) {
        BillingDispute dispute = billingDisputeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("BillingDispute not found with id: " + id));
        dispute.setStatus(status);
        BillingDispute saved = billingDisputeRepository.save(dispute);
        auditLogService.log("UPDATE", "BillingDispute", String.valueOf(saved.getDisputeId()), null);
        return mapToResponse(saved);
    }

    @Override
    public BillingDisputeResponse getDisputeById(Long id) {
        BillingDispute dispute = billingDisputeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Dispute not found with id: " + id));
        return mapToResponse(dispute);
    }

    @Override
    public List<BillingDisputeResponse> getDisputesByConsumer(Long consumerId) {
        return billingDisputeRepository.findByConsumer_UserId(consumerId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<BillingDisputeResponse> getDisputesByStatus(DisputeStatus status) {
        return billingDisputeRepository.findByStatus(status).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public BillingDisputeResponse reviewDispute(Long id) {
        BillingDispute dispute = billingDisputeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Dispute not found with id: " + id));
        dispute.setStatus(DisputeStatus.UNDER_REVIEW);
        BillingDispute saved = billingDisputeRepository.save(dispute);
        auditLogService.log("UPDATE", "BillingDispute", String.valueOf(saved.getDisputeId()),
                saved.getConsumer() != null ? saved.getConsumer().getUserId() : null);
        return mapToResponse(saved);
    }

    @Override
    public BillingDisputeResponse resolveDispute(Long id) {
        BillingDispute dispute = billingDisputeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Dispute not found with id: " + id));
        dispute.setStatus(DisputeStatus.RESOLVED);
        BillingDispute saved = billingDisputeRepository.save(dispute);
        auditLogService.log("UPDATE", "BillingDispute", String.valueOf(saved.getDisputeId()),
                saved.getConsumer() != null ? saved.getConsumer().getUserId() : null);
        return mapToResponse(saved);
    }

    @Override
    public BillingDisputeResponse rejectDispute(Long id) {
        BillingDispute dispute = billingDisputeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Dispute not found with id: " + id));
        dispute.setStatus(DisputeStatus.REJECTED);
        BillingDispute saved = billingDisputeRepository.save(dispute);
        auditLogService.log("UPDATE", "BillingDispute", String.valueOf(saved.getDisputeId()),
                saved.getConsumer() != null ? saved.getConsumer().getUserId() : null);
        return mapToResponse(saved);
    }

    private BillingDisputeResponse mapToResponse(BillingDispute dispute) {
        return new BillingDisputeResponse(
                dispute.getDisputeId(),
                dispute.getBill() != null ? dispute.getBill().getBillId() : null,
                dispute.getConsumer() != null ? dispute.getConsumer().getUserId() : null,
                dispute.getReason(),
                dispute.getRaisedDate(),
                dispute.getStatus());
    }
}
