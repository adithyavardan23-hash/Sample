package com.cts.energygrid.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.energygrid.dto.request.BillRequest;
import com.cts.energygrid.dto.response.BillResponse;
import com.cts.energygrid.entity.Bill;
import com.cts.energygrid.entity.ConsumerAccount;
import com.cts.energygrid.entity.Tariff;
import com.cts.energygrid.enums.BillStatus;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.BillRepository;
import com.cts.energygrid.repository.ConsumerAccountRepository;
import com.cts.energygrid.repository.TariffRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.BillingService;

@Service
public class BillingServiceImpl implements BillingService {

    @Autowired
    private BillRepository billRepository;

    @Autowired
    private ConsumerAccountRepository consumerAccountRepository;

    @Autowired
    private TariffRepository tariffRepository;

    @Autowired
    private AuditLogService auditLogService;

    @Override
    public BillResponse generateBill(BillRequest req) {
        ConsumerAccount account = consumerAccountRepository.findById(req.getAccountId())
                .orElseThrow(() -> new ResourceNotFoundException("ConsumerAccount not found with id: " + req.getAccountId()));
        Tariff tariff = tariffRepository.findById(req.getTariffId())
                .orElseThrow(() -> new ResourceNotFoundException("Tariff not found with id: " + req.getTariffId()));

        double rate = parseRate(tariff.getSlabRates());
        double fixed = tariff.getFixedCharges() != null ? tariff.getFixedCharges() : 0.0;
        double taxPct = tariff.getTaxRates() != null ? tariff.getTaxRates() : 0.0;
        double units = req.getUnitsConsumed() != null ? req.getUnitsConsumed() : 0.0;
        double energy = units * rate;
        double tax = energy * (taxPct / 100.0);
        double total = energy + fixed + tax;

        Bill bill = new Bill();
        bill.setAccount(account);
        bill.setBillingPeriodStart(req.getBillingPeriodStart());
        bill.setBillingPeriodEnd(req.getBillingPeriodEnd());
        bill.setUnitsConsumed(req.getUnitsConsumed());
        bill.setTariff(tariff);
        bill.setTotalAmount(total);
        bill.setDueDate(req.getDueDate());
        bill.setStatus(BillStatus.GENERATED);

        Bill saved = billRepository.save(bill);
        auditLogService.log("GENERATE_BILL", "Bill", String.valueOf(saved.getBillId()), account.getAccountId());
        return mapToResponse(saved);
    }

    @Override
    public BillResponse getBillById(Long id) {
        Bill bill = billRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Bill not found with id: " + id));
        return mapToResponse(bill);
    }

    @Override
    public List<BillResponse> getBillsByAccount(Long accountId) {
        return billRepository.findByAccount_AccountId(accountId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public BillResponse updateStatus(Long id, BillStatus status) {
        Bill bill = billRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Bill not found with id: " + id));
        bill.setStatus(status);
        Bill saved = billRepository.save(bill);
        auditLogService.log("UPDATE", "Bill", String.valueOf(saved.getBillId()), null);
        return mapToResponse(saved);
    }

    @Override
    public List<BillResponse> getOverdueBills() {
        return billRepository.findByStatus(BillStatus.OVERDUE).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public BillResponse sendBill(Long id) {
        Bill bill = billRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Bill not found with id: " + id));
        bill.setStatus(BillStatus.SENT);
        Bill saved = billRepository.save(bill);
        auditLogService.log("UPDATE", "Bill", String.valueOf(saved.getBillId()),
                saved.getAccount() != null ? saved.getAccount().getAccountId() : null);
        return mapToResponse(saved);
    }

    @Override
    public BillResponse markAsPaid(Long id) {
        Bill bill = billRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Bill not found with id: " + id));
        bill.setStatus(BillStatus.PAID);
        Bill saved = billRepository.save(bill);
        auditLogService.log("UPDATE", "Bill", String.valueOf(saved.getBillId()),
                saved.getAccount() != null ? saved.getAccount().getAccountId() : null);
        return mapToResponse(saved);
    }

    @Override
    public BillResponse markAsOverdue(Long id) {
        Bill bill = billRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Bill not found with id: " + id));
        bill.setStatus(BillStatus.OVERDUE);
        Bill saved = billRepository.save(bill);
        auditLogService.log("UPDATE", "Bill", String.valueOf(saved.getBillId()),
                saved.getAccount() != null ? saved.getAccount().getAccountId() : null);
        return mapToResponse(saved);
    }

    @Override
    public List<BillResponse> getBillsByStatus(BillStatus status) {
        return billRepository.findByStatus(status).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    private double parseRate(String slabRates) {
        if (slabRates == null) {
            return 5.0;
        }
        try {
            StringBuilder sb = new StringBuilder();
            boolean started = false;
            boolean dotSeen = false;
            for (char c : slabRates.trim().toCharArray()) {
                if (Character.isDigit(c)) {
                    sb.append(c);
                    started = true;
                } else if (c == '.' && started && !dotSeen) {
                    sb.append(c);
                    dotSeen = true;
                } else if (started) {
                    break;
                }
            }
            if (sb.length() == 0) {
                return 5.0;
            }
            return Double.parseDouble(sb.toString());
        } catch (Exception e) {
            return 5.0;
        }
    }

    private BillResponse mapToResponse(Bill bill) {
        return new BillResponse(
                bill.getBillId(),
                bill.getAccount() != null ? bill.getAccount().getAccountId() : null,
                bill.getBillingPeriodStart(),
                bill.getBillingPeriodEnd(),
                bill.getUnitsConsumed(),
                bill.getTariff() != null ? bill.getTariff().getTariffId() : null,
                bill.getTotalAmount(),
                bill.getDueDate(),
                bill.getStatus());
    }
}
