package com.cts.energygrid.service.impl;

import com.cts.energygrid.dto.request.NotificationRequest;
import com.cts.energygrid.dto.response.NotificationResponse;
import com.cts.energygrid.entity.Notification;
import com.cts.energygrid.entity.User;
import com.cts.energygrid.enums.NotificationStatus;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.NotificationRepository;
import com.cts.energygrid.repository.UserRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuditLogService auditLogService;

    @Override
    public NotificationResponse sendNotification(NotificationRequest req) {
        User user = userRepository.findById(req.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + req.getUserId()));

        Notification notification = new Notification();
        notification.setUser(user);
        notification.setMessage(req.getMessage());
        notification.setCategory(req.getCategory());
        notification.setStatus(NotificationStatus.UNREAD);
        notification.setCreatedDate(LocalDateTime.now());

        Notification saved = notificationRepository.save(notification);
        auditLogService.log("CREATE", "Notification", String.valueOf(saved.getNotificationId()), req.getUserId());
        return mapToResponse(saved);
    }

    @Override
    public List<NotificationResponse> getByUser(Long userId) {
        return notificationRepository.findByUser_UserId(userId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<NotificationResponse> getUnreadByUser(Long userId) {
        return notificationRepository.findByUser_UserIdAndStatus(userId, NotificationStatus.UNREAD).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public NotificationResponse markAsRead(Long id) {
        Notification notification = notificationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found with id: " + id));
        notification.setStatus(NotificationStatus.READ);
        Notification saved = notificationRepository.save(notification);
        auditLogService.log("UPDATE", "Notification", String.valueOf(saved.getNotificationId()),
                saved.getUser() != null ? saved.getUser().getUserId() : null);
        return mapToResponse(saved);
    }

    @Override
    public NotificationResponse dismissNotification(Long id) {
        Notification notification = notificationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found with id: " + id));
        notification.setStatus(NotificationStatus.DISMISSED);
        Notification saved = notificationRepository.save(notification);
        auditLogService.log("UPDATE", "Notification", String.valueOf(saved.getNotificationId()),
                notification.getUser() != null ? notification.getUser().getUserId() : null);
        return mapToResponse(saved);
    }

    private NotificationResponse mapToResponse(Notification notification) {
        Long userId = notification.getUser() != null ? notification.getUser().getUserId() : null;
        return new NotificationResponse(
                notification.getNotificationId(),
                userId,
                notification.getMessage(),
                notification.getCategory(),
                notification.getStatus(),
                notification.getCreatedDate()
        );
    }
}
