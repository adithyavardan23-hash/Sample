package com.cts.energygrid.dto.request;

import com.cts.energygrid.enums.OutageCause;
import java.time.LocalDateTime;

public class OutageEventRequest {

    private String zoneId;
    private Integer affectedAccounts;
    private OutageCause cause;
    private LocalDateTime startTime;
    private LocalDateTime estimatedRestoration;

    public OutageEventRequest() {
    }

    public OutageEventRequest(String zoneId, Integer affectedAccounts, OutageCause cause,
                              LocalDateTime startTime, LocalDateTime estimatedRestoration) {
        this.zoneId = zoneId;
        this.affectedAccounts = affectedAccounts;
        this.cause = cause;
        this.startTime = startTime;
        this.estimatedRestoration = estimatedRestoration;
    }

    public String getZoneId() {
        return zoneId;
    }

    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }

    public Integer getAffectedAccounts() {
        return affectedAccounts;
    }

    public void setAffectedAccounts(Integer affectedAccounts) {
        this.affectedAccounts = affectedAccounts;
    }

    public OutageCause getCause() {
        return cause;
    }

    public void setCause(OutageCause cause) {
        this.cause = cause;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEstimatedRestoration() {
        return estimatedRestoration;
    }

    public void setEstimatedRestoration(LocalDateTime estimatedRestoration) {
        this.estimatedRestoration = estimatedRestoration;
    }
}
