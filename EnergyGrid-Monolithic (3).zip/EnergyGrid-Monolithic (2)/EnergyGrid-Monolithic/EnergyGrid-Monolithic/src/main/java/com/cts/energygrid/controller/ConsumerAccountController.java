package com.cts.energygrid.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.energygrid.dto.request.ConsumerAccountRequest;
import com.cts.energygrid.dto.response.ConsumerAccountResponse;
import com.cts.energygrid.enums.AccountStatus;
import com.cts.energygrid.service.ConsumerAccountService;

@RestController
@RequestMapping("/api/accounts")
public class ConsumerAccountController {

    @Autowired
    private ConsumerAccountService consumerAccountService;

    @PostMapping("")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ConsumerAccountResponse> createAccount(@RequestBody ConsumerAccountRequest req) {
        return ResponseEntity.ok(consumerAccountService.createAccount(req));
    }

    @GetMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','COMPLIANCE')")
    public ResponseEntity<List<ConsumerAccountResponse>> getAllAccounts() {
        return ResponseEntity.ok(consumerAccountService.getAllAccounts());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','COMPLIANCE','CONSUMER')")
    public ResponseEntity<ConsumerAccountResponse> getAccountById(@PathVariable Long id) {
        return ResponseEntity.ok(consumerAccountService.getAccountById(id));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ConsumerAccountResponse> updateStatus(@PathVariable Long id,
            @RequestParam AccountStatus status) {
        return ResponseEntity.ok(consumerAccountService.updateStatus(id, status));
    }

    @GetMapping("/consumer/{consumerId}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','CONSUMER')")
    public ResponseEntity<ConsumerAccountResponse> getAccountByConsumerId(@PathVariable Long consumerId) {
        return ResponseEntity.ok(consumerAccountService.getAccountByConsumerId(consumerId));
    }

    @GetMapping("/zone/{zoneId}")
    @PreAuthorize("hasAnyRole('ADMIN','GRID_OPS')")
    public ResponseEntity<List<ConsumerAccountResponse>> getAccountsByZone(@PathVariable String zoneId) {
        return ResponseEntity.ok(consumerAccountService.getAccountsByZone(zoneId));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<ConsumerAccountResponse> updateAccount(@PathVariable Long id,
            @RequestBody ConsumerAccountRequest req) {
        return ResponseEntity.ok(consumerAccountService.updateAccount(id, req));
    }

    @PatchMapping("/{id}/suspend")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ConsumerAccountResponse> suspendAccount(@PathVariable Long id) {
        return ResponseEntity.ok(consumerAccountService.suspendAccount(id));
    }

    @PatchMapping("/{id}/disconnect")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ConsumerAccountResponse> disconnectAccount(@PathVariable Long id) {
        return ResponseEntity.ok(consumerAccountService.disconnectAccount(id));
    }

    @PatchMapping("/{id}/reactivate")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ConsumerAccountResponse> reactivateAccount(@PathVariable Long id) {
        return ResponseEntity.ok(consumerAccountService.reactivateAccount(id));
    }
}
