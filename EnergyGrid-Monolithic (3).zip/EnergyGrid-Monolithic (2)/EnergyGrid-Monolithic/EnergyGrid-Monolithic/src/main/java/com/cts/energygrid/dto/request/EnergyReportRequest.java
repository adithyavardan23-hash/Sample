package com.cts.energygrid.dto.request;

import com.cts.energygrid.enums.ReportScope;

public class EnergyReportRequest {

    private ReportScope scope;

    public EnergyReportRequest() {
    }

    public EnergyReportRequest(ReportScope scope) {
        this.scope = scope;
    }

    public ReportScope getScope() {
        return scope;
    }

    public void setScope(ReportScope scope) {
        this.scope = scope;
    }
}
