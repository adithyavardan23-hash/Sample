package com.cts.energygrid.service.impl;

import com.cts.energygrid.dto.response.EnergyReportResponse;
import com.cts.energygrid.entity.EnergyReport;
import com.cts.energygrid.enums.ReportScope;
import com.cts.energygrid.exception.ResourceNotFoundException;
import com.cts.energygrid.repository.EnergyReportRepository;
import com.cts.energygrid.service.AuditLogService;
import com.cts.energygrid.service.EnergyReportService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class EnergyReportServiceImpl implements EnergyReportService {

    @Autowired
    private EnergyReportRepository energyReportRepository;

    @Autowired
    private AuditLogService auditLogService;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public EnergyReportResponse generateReport(ReportScope scope) {
        Map<String, Object> metrics = new LinkedHashMap<>();
        metrics.put("scope", scope.name());
        metrics.put("totalConsumption", 12345.6);
        metrics.put("activeAccounts", 100);
        metrics.put("generatedFor", scope.getDisplayName());

        String json;
        try {
            json = objectMapper.writeValueAsString(metrics);
        } catch (Exception e) {
            json = metrics.toString();
        }

        EnergyReport report = new EnergyReport();
        report.setScope(scope);
        report.setMetrics(json);
        report.setGeneratedDate(LocalDateTime.now());

        EnergyReport saved = energyReportRepository.save(report);
        auditLogService.log("CREATE", "EnergyReport", String.valueOf(saved.getReportId()), saved.getReportId());
        return mapToResponse(saved);
    }

    @Override
    public List<EnergyReportResponse> getAllReports() {
        return energyReportRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public EnergyReportResponse getReportById(Long id) {
        EnergyReport report = energyReportRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Report not found with id: " + id));
        return mapToResponse(report);
    }

    @Override
    public List<EnergyReportResponse> getReportsByScope(ReportScope scope) {
        return energyReportRepository.findByScope(scope).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<EnergyReportResponse> getReportsForPeriod(LocalDateTime from, LocalDateTime to) {
        return energyReportRepository.findByGeneratedDateBetween(from, to).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    /*
     * Dashboard summary: total report count, a breakdown of how many reports exist
     * per ReportScope, and the timestamp of the most recently generated report.
     */
    @Override
    public Map<String, Object> getSummary() {
        List<EnergyReport> reports = energyReportRepository.findAll();

        Map<String, Long> countByScope = new LinkedHashMap<>();
        for (ReportScope scope : ReportScope.values()) {
            countByScope.put(scope.name(), 0L);
        }
        LocalDateTime latest = null;
        for (EnergyReport report : reports) {
            if (report.getScope() != null) {
                countByScope.merge(report.getScope().name(), 1L, Long::sum);
            }
            if (report.getGeneratedDate() != null
                    && (latest == null || report.getGeneratedDate().isAfter(latest))) {
                latest = report.getGeneratedDate();
            }
        }

        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("totalReports", (long) reports.size());
        summary.put("countByScope", countByScope);
        summary.put("latestReportDate", latest);
        return summary;
    }

    private EnergyReportResponse mapToResponse(EnergyReport report) {
        return new EnergyReportResponse(
                report.getReportId(),
                report.getScope(),
                report.getMetrics(),
                report.getGeneratedDate()
        );
    }
}
