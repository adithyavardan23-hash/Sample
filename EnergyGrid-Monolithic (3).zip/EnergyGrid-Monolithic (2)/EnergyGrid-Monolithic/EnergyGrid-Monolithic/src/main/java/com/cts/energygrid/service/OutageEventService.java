package com.cts.energygrid.service;

import com.cts.energygrid.dto.request.OutageEventRequest;
import com.cts.energygrid.dto.response.OutageEventResponse;
import com.cts.energygrid.enums.OutageStatus;

import java.time.LocalDateTime;
import java.util.List;

public interface OutageEventService {

    OutageEventResponse logOutage(OutageEventRequest req);

    OutageEventResponse getOutageById(Long id);

    List<OutageEventResponse> getActiveOutages();

    OutageEventResponse restoreOutage(Long id);

    OutageEventResponse updateStatus(Long id, OutageStatus status);

    List<OutageEventResponse> getOutagesByZone(String zoneId);

    OutageEventResponse updateEstimatedRestoration(Long id, LocalDateTime time);
}
