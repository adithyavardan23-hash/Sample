package com.cts.energygrid.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.cts.energygrid.repository.UserRepository;

/*
 * Helper bean used inside @PreAuthorize SpEL expressions, e.g.
 *   @PreAuthorize("... or @userSecurity.isSelf(#id, authentication)")
 *
 * The JWT principal is the user's EMAIL (see JwtFilter), so to decide whether a
 * caller is acting on their own record we load the target user by id and compare
 * its email to the authenticated principal.
 */
@Component("userSecurity")
public class UserSecurity {

    @Autowired
    private UserRepository userRepository;

    public boolean isSelf(Long id, Authentication authentication) {
        if (id == null || authentication == null || authentication.getName() == null) {
            return false;
        }
        String principalEmail = authentication.getName(); // principal == email
        return userRepository.findById(id)
                .map(user -> principalEmail.equalsIgnoreCase(user.getEmail()))
                .orElse(false);
    }
}
