package com.cts.energygrid.service;

import com.cts.energygrid.dto.request.NotificationRequest;
import com.cts.energygrid.dto.response.NotificationResponse;

import java.util.List;

public interface NotificationService {

    NotificationResponse sendNotification(NotificationRequest req);

    List<NotificationResponse> getByUser(Long userId);

    List<NotificationResponse> getUnreadByUser(Long userId);

    NotificationResponse markAsRead(Long id);

    NotificationResponse dismissNotification(Long id);
}
