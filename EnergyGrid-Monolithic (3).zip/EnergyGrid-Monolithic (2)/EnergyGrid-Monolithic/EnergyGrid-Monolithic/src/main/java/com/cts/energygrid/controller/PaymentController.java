package com.cts.energygrid.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.energygrid.dto.request.PaymentRequest;
import com.cts.energygrid.dto.response.PaymentResponse;
import com.cts.energygrid.service.PaymentService;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','CONSUMER')")
    public ResponseEntity<PaymentResponse> recordPayment(@RequestBody PaymentRequest request) {
        return ResponseEntity.ok(paymentService.recordPayment(request));
    }

    @GetMapping("/account/{accountId}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','CONSUMER')")
    public ResponseEntity<List<PaymentResponse>> getPaymentsByAccount(@PathVariable Long accountId) {
        return ResponseEntity.ok(paymentService.getPaymentsByAccount(accountId));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','CONSUMER')")
    public ResponseEntity<PaymentResponse> getPaymentById(@PathVariable Long id) {
        return ResponseEntity.ok(paymentService.getPaymentById(id));
    }

    @GetMapping("/bill/{billId}")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING','CONSUMER')")
    public ResponseEntity<List<PaymentResponse>> getPaymentsByBill(@PathVariable Long billId) {
        return ResponseEntity.ok(paymentService.getPaymentsByBill(billId));
    }

    @GetMapping("/failed")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<List<PaymentResponse>> getFailedPayments() {
        return ResponseEntity.ok(paymentService.getFailedPayments());
    }

    @PatchMapping("/{id}/retry")
    @PreAuthorize("hasAnyRole('ADMIN','BILLING')")
    public ResponseEntity<PaymentResponse> retryPayment(@PathVariable Long id) {
        return ResponseEntity.ok(paymentService.retryPayment(id));
    }
}
