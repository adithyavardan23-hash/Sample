package com.cts.energygrid.dto.response;

import com.cts.energygrid.enums.ReadingSource;
import com.cts.energygrid.enums.ReadingStatus;
import java.time.LocalDate;

public class MeterReadingResponse {

    private Long readingId;
    private Long meterId;
    private Double readingValue;
    private LocalDate readingDate;
    private ReadingSource source;
    private ReadingStatus status;

    public MeterReadingResponse() {
    }

    public MeterReadingResponse(Long readingId, Long meterId, Double readingValue, LocalDate readingDate, ReadingSource source, ReadingStatus status) {
        this.readingId = readingId;
        this.meterId = meterId;
        this.readingValue = readingValue;
        this.readingDate = readingDate;
        this.source = source;
        this.status = status;
    }

    public Long getReadingId() {
        return readingId;
    }

    public void setReadingId(Long readingId) {
        this.readingId = readingId;
    }

    public Long getMeterId() {
        return meterId;
    }

    public void setMeterId(Long meterId) {
        this.meterId = meterId;
    }

    public Double getReadingValue() {
        return readingValue;
    }

    public void setReadingValue(Double readingValue) {
        this.readingValue = readingValue;
    }

    public LocalDate getReadingDate() {
        return readingDate;
    }

    public void setReadingDate(LocalDate readingDate) {
        this.readingDate = readingDate;
    }

    public ReadingSource getSource() {
        return source;
    }

    public void setSource(ReadingSource source) {
        this.source = source;
    }

    public ReadingStatus getStatus() {
        return status;
    }

    public void setStatus(ReadingStatus status) {
        this.status = status;
    }
}
