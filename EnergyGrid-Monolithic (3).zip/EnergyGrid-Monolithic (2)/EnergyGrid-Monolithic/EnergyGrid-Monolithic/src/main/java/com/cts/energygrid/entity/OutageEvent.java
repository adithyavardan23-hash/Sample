package com.cts.energygrid.entity;

import com.cts.energygrid.enums.OutageCause;
import com.cts.energygrid.enums.OutageStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "outage_events")
public class OutageEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long outageId;

    private String zoneId;

    private Integer affectedAccounts;

    @Enumerated(EnumType.STRING)
    @Column
    private OutageCause cause;

    private LocalDateTime startTime;

    private LocalDateTime estimatedRestoration;

    private LocalDateTime actualRestoration;

    @Enumerated(EnumType.STRING)
    @Column
    private OutageStatus status;

    public OutageEvent() {
    }

    public Long getOutageId() {
        return outageId;
    }

    public void setOutageId(Long outageId) {
        this.outageId = outageId;
    }

    public String getZoneId() {
        return zoneId;
    }

    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }

    public Integer getAffectedAccounts() {
        return affectedAccounts;
    }

    public void setAffectedAccounts(Integer affectedAccounts) {
        this.affectedAccounts = affectedAccounts;
    }

    public OutageCause getCause() {
        return cause;
    }

    public void setCause(OutageCause cause) {
        this.cause = cause;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEstimatedRestoration() {
        return estimatedRestoration;
    }

    public void setEstimatedRestoration(LocalDateTime estimatedRestoration) {
        this.estimatedRestoration = estimatedRestoration;
    }

    public LocalDateTime getActualRestoration() {
        return actualRestoration;
    }

    public void setActualRestoration(LocalDateTime actualRestoration) {
        this.actualRestoration = actualRestoration;
    }

    public OutageStatus getStatus() {
        return status;
    }

    public void setStatus(OutageStatus status) {
        this.status = status;
    }
}
