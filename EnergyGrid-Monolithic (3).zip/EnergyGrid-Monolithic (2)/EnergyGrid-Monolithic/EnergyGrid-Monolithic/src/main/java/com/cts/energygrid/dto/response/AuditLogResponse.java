package com.cts.energygrid.dto.response;

import java.time.LocalDateTime;

/*
 * PROBLEM 5 FIX:
 * The controller used to return the AuditLog ENTITY directly. We now return this
 * flat DTO instead. (In this codebase AuditLog stores a `performedBy` user id
 * rather than a @ManyToOne User, so there is no Jackson recursion today — but
 * returning a DTO keeps the API stable and lets us enrich it with the user's
 * name/email, which the frontend needs.)
 *
 * userId  = AuditLog.performedBy
 * userName / userEmail = resolved from the User table (null if the user is gone).
 */
public class AuditLogResponse {

    private Long auditId;
    private Long userId;
    private String userName;
    private String userEmail;
    private String action;
    private String entityType;
    private String entityId;
    private LocalDateTime timestamp;

    public AuditLogResponse() {
    }

    public Long getAuditId() {
        return auditId;
    }

    public void setAuditId(Long auditId) {
        this.auditId = auditId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getEntityType() {
        return entityType;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
