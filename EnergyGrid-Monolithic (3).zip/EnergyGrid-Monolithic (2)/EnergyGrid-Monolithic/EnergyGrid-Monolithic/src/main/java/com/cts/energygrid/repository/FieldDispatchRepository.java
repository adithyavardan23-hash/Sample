package com.cts.energygrid.repository;

import com.cts.energygrid.entity.FieldDispatch;
import com.cts.energygrid.enums.DispatchStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FieldDispatchRepository extends JpaRepository<FieldDispatch, Long> {

    List<FieldDispatch> findByOutage_OutageId(Long outageId);

    List<FieldDispatch> findByTechnician_UserId(Long techId);

    List<FieldDispatch> findByStatus(DispatchStatus status);
}
