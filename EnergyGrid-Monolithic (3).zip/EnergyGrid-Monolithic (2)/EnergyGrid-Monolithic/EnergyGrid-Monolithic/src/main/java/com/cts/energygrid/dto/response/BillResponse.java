package com.cts.energygrid.dto.response;

import java.time.LocalDate;

import com.cts.energygrid.enums.BillStatus;

public class BillResponse {

    private Long billId;
    private Long accountId;
    private LocalDate billingPeriodStart;
    private LocalDate billingPeriodEnd;
    private Double unitsConsumed;
    private Long tariffId;
    private Double totalAmount;
    private LocalDate dueDate;
    private BillStatus status;

    public BillResponse() {
    }

    public BillResponse(Long billId, Long accountId, LocalDate billingPeriodStart, LocalDate billingPeriodEnd,
                        Double unitsConsumed, Long tariffId, Double totalAmount, LocalDate dueDate, BillStatus status) {
        this.billId = billId;
        this.accountId = accountId;
        this.billingPeriodStart = billingPeriodStart;
        this.billingPeriodEnd = billingPeriodEnd;
        this.unitsConsumed = unitsConsumed;
        this.tariffId = tariffId;
        this.totalAmount = totalAmount;
        this.dueDate = dueDate;
        this.status = status;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public LocalDate getBillingPeriodStart() {
        return billingPeriodStart;
    }

    public void setBillingPeriodStart(LocalDate billingPeriodStart) {
        this.billingPeriodStart = billingPeriodStart;
    }

    public LocalDate getBillingPeriodEnd() {
        return billingPeriodEnd;
    }

    public void setBillingPeriodEnd(LocalDate billingPeriodEnd) {
        this.billingPeriodEnd = billingPeriodEnd;
    }

    public Double getUnitsConsumed() {
        return unitsConsumed;
    }

    public void setUnitsConsumed(Double unitsConsumed) {
        this.unitsConsumed = unitsConsumed;
    }

    public Long getTariffId() {
        return tariffId;
    }

    public void setTariffId(Long tariffId) {
        this.tariffId = tariffId;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public BillStatus getStatus() {
        return status;
    }

    public void setStatus(BillStatus status) {
        this.status = status;
    }
}
