package com.cts.energygrid.enums;

public enum MeterStatus {
    ACTIVE("Active"),
    FAULTY("Faulty"),
    REPLACED("Replaced");

    private final String displayName;

    MeterStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
